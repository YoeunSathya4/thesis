<?php $__env->startSection('section-title', 'Feature'); ?>
<?php $__env->startSection('hide-btn-back', 'display:none'); ?>
<?php $__env->startSection('section-css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('section-js'); ?>
	<script type="text/JavaScript">
			
	</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section-content'); ?>
	<?php if(sizeof($data) > 0): ?>
		<div class="table-responsive">
			<table id="table-edit" class="table table-bordered table-hover">
				<thead>
					<tr>
						<th>#</th>
						<th>Title</th>
						<th>N. of Accesses</th>
						<th>Updated Date</th>
						<th></th>
					</tr>
				</thead>
				<tbody>

					<?php ($i = 1); ?>
					<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($i++); ?></td>
							<td><?php echo e($row->name); ?></td>
							
							<td><?php echo e(count($row->accesses)); ?></td>
							<td><?php echo e($row->updated_at); ?></td>
							<td style="white-space: nowrap; width: 1%;">
								<div class="tabledit-toolbar btn-toolbar" style="text-align: left;">
		                           	<div class="btn-group btn-group-sm" style="float: none;">
		                           		<a href="<?php echo e(route($route.'.edit', $row->id)); ?>" class="tabledit-edit-button btn btn-sm btn-success" style="float: none;"><span class="fa fa-eye"></span></a>
		                           		<a href="#" onclick="deleteConfirm('<?php echo e(route($route.'.trash', $row->id)); ?>', '<?php echo e(route($route.'.index')); ?>')" class="tabledit-delete-button btn btn-sm btn-danger" style="float: none;"><span class="glyphicon glyphicon-trash"></span></a>
		                           	</div>
		                       </div>
		                    </td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div >
	<?php else: ?>
		<span>No Data</span>
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($route.'.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>