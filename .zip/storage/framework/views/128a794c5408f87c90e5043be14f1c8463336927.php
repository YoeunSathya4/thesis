<?php $__env->startSection('section-title', 'Edit Menu'); ?>
<?php $__env->startSection('tab-active-menu', 'active'); ?>
<?php $__env->startSection('about-active-overview', 'active'); ?>

<?php $__env->startSection('tab-css'); ?>
	<link href="<?php echo e(asset ('public/cp/css/plugin/fileinput/fileinput.min.css')); ?>" media="all" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset ('public/cp/css/plugin/fileinput/theme.css')); ?>" media="all" rel="stylesheet" type="text/css"/>
	<!-- some CSS styling changes and overrides -->
	<style>
		.kv-avatar .file-preview-frame,.kv-avatar .file-preview-frame:hover {
		    margin: 0;
		    padding: 0;
		    border: none;
		    box-shadow: none;
		    text-align: center;
		}
		.kv-avatar .file-input {
		    display: table-cell;
		    max-width: 200px;
		}
	</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('imageuploadjs'); ?>
    <script type="text/javascript" src="<?php echo e(asset ('public/cp/js/plugin/fileinput/fileinput.min.js')); ?>" type="text/javascript"></script>
    <script type="text/javascript" src="<?php echo e(asset ('public/cp/js/plugin/fileinput/theme.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section-js'); ?>
	<script type="text/JavaScript">
		$(document).ready(function(event){
			$('#form').validate({
				modules : 'file',
				submit: {
					settings: {
						inputContainer: '.form-group',
						errorListClass: 'form-tooltip-error'
					}
				}
			}); 
			
		}); 
		function change_active(){
			val 	= $('#active').val();
			if(val == 0){
				$('#active').val(1);
			}else{
				$('#active').val(0);
			}
		}
	</script>
	<script type="text/JavaScript">
		
		var btnCust = ''; 
		$("#image").fileinput({
		    overwriteInitial: true,
		    maxFileSize: 1500,
		    showClose: false,
		    showCaption: false,
		    showBrowse: false,
		    browseOnZoneClick: true,
		    removeLabel: '',
		    removeIcon: '<i class="glyphicon glyphicon-remove"></i>',
		    removeTitle: 'Cancel or reset changes',
		    elErrorContainer: '#kv-avatar-errors-2',
		    msgErrorClass: 'alert alert-block alert-danger',
		    defaultPreviewContent: '<img src="<?php if($data->image != ''): ?> <?php echo e(asset('public/uploads/restaurant/menu/'.$data->image)); ?> <?php else: ?> http://via.placeholder.com/200x200 <?php endif; ?>" alt="Missing Image" class="img img-responsive"><span class="text-muted">Click to select <br /><i style="font-size:12px">Image dimesion must be 200x200 px with .jpg or .png type</i></span>',
		    layoutTemplates: {main2: '{preview} ' +  btnCust + ' {remove} {browse}'},
		    allowedFileExtensions: ["jpg", "png", "gif"]
		});
	
	</script>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('about'); ?>
	<br />
	<div class="row">
		<div class="col-md-12">
			<a href="<?php echo e(route('cp.restaurant.menu.create', $id)); ?>" class="tabledit-delete-button btn btn-sm btn-primary" style="float: right; margin-left: 4px;"><span class="fa fa-plus"></span></a> &nbsp;
			<a href="<?php echo e(route('cp.restaurant.menu.index', $id)); ?>" class="tabledit-delete-button btn btn-sm btn-primary" style="float: right;"><span class="fa fa-arrow-left"></span></a>
		</div>
	</div><!--.row-->
	<?php echo $__env->make('cp.layouts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<form id="form" action="<?php echo e(route('cp.restaurant.menu.update')); ?>" name="form" method="POST"  enctype="multipart/form-data">
		<?php echo e(csrf_field()); ?>

		<?php echo e(method_field('POST')); ?>

		<input type="hidden" name="restaurant_id" value="<?php echo e($id); ?>">
		<input type="hidden" name="menu_id" value="<?php echo e($data->id); ?>">

		<div class="form-group row">
				<label for="type_id" class="col-sm-2 form-control-label">Type</label>
				<div class="col-sm-10">
					<select id="type_id" name="type_id" class="form-control">
						
						<?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
								<option value="<?php echo e($row->id); ?>" <?php if($data->type_id == $row->id): ?> selected <?php endif; ?> ><?php echo e($row->name); ?></option>
							
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
		</div>
		<div class="form-group row">
				<label for="category_id" class="col-sm-2 form-control-label">Category</label>
				<div class="col-sm-10">
					<select id="category_id" name="category_id" class="form-control">
						
						<?php $__currentLoopData = $restaurant_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
								<option value="<?php echo e($row->category->id); ?>" <?php if($data->category_id == $row->category->id): ?> selected <?php endif; ?> ><?php echo e($row->category->name); ?></option>
							
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-2 form-control-label" for="name">Name</label>
				<div class="col-sm-10">
					<input 	id="name"
							name="name"
						   	value = "<?php echo e($data->name); ?>"
						   	type="text"
						   	placeholder = "Eg. Jhon Son"
						   	class="form-control"
						   	data-validation="[L>=1, L<=30]"
							data-validation-message="$ must be between 2 and 18 characters. No special characters allowed." />
							
				</div>
			</div>

			<div class="form-group row">
				<label class="col-sm-2 form-control-label" for="email">Image</label>
				<div class="col-sm-10">
					<div class="kv-avatar center-block">
				        <input id="image" name="image" type="file" class="file-loading">
				    </div>
				</div>
			</div>
			
			<div class="form-group row">
				<label class="col-sm-2 form-control-label" for="instruction">Instruction</label>
				<div class="col-sm-10">
					<textarea class="form-control" name="instruction" ><?php echo e($data->instruction); ?></textarea>
				</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-2 form-control-label" for="kh_content">Publish</label>
				<div class="col-sm-10">
					<div class="checkbox-toggle">
						<input id="status-is_published" type="checkbox"  <?php if($data->is_published ==1 ): ?> checked <?php endif; ?> >
						<label onclick="booleanForm('is_published')" for="status-is_published"></label>
					</div>
					<input type="hidden" name="is_published" id="is_published" value="<?php echo e($data->is_published); ?>">
				</div>
			</div>
		
		<div class="form-group row">
			<label class="col-sm-2 form-control-label"></label>
			<div class="col-sm-10">
				<button type="submit" class="btn btn-success"> <fa class="fa fa-cog"></i> Update</button>
				<button type="button" onclick="deleteConfirm('<?php echo e(route('cp.restaurant.menu.trash', ['id'=>$id, 'menu_id'=>$data->id])); ?>', '<?php echo e(route('cp.restaurant.menu.index', $id)); ?>')" class="btn btn-danger"> <fa class="fa fa-trash"></i> Delete</button>
			</div>
		</div>
	</form>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cp.restaurant.menu.tabForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>