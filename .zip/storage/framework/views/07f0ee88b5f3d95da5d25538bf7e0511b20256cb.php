<?php $__env->startSection('title', 'Search Your Properties'); ?>
<?php $__env->startSection('property', 'active'); ?>

<?php $__env->startSection('appbottomjs'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  	<div class="findhome-subheader">
    <div class="findhome-subheader-image">
        <span class="findhome-dark-transparent"></span>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1><?php echo e(__('web.property-result')); ?></h1>
                </div>
            </div>
        </div>
    </div>
    <div class="findhome-breadcrumb">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <ul>
                        <li><a href="<?php echo e(route('home',$locale)); ?>"><?php echo e(__('general.home')); ?></a></li>
                        <li class="findhome-color"><?php echo e(__('web.property-result')); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>      
<div class="findhome-main-content">

    <!--// Main Section \\-->
    <div class="findhome-main-section">
        <div class="container">
            <div class="row">
                <?php echo $__env->make('frontend.layouts.sidebar.property-search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="col-md-9">
                    <div class="findhome-listing findhome-listing-list">
                        <ul class="row">
                            <?php if(sizeof($data) > 0): ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="col-md-12">
                                <figure><a href="listing-detail.html"><img src="<?php echo e(asset ('public/frontend/extra-images/listing-list-img1.jpg')); ?>" alt=""><i class="fa fa-link"></i><span class="img-transparent"></span></a></figure>
                                <div class="findhome-listing-list-wrap">
                                    <div class="findhome-listing-list-text">
                                        <h5><a href="<?php echo e(route('property-detail',['locale'=>$locale,'slug'=>$row->slug])); ?>"><?php echo e($row->name); ?></a></h5>

                                        <span><i class="fa fa-map-marker"></i> <?php echo e($row->location->address); ?> </span> 
                                         <p><?php echo e($row->description); ?></p>
                                        
                                    </div>
                                    <div class="findhome-user-post">
                                        <ul class="findhome-listing-option">

                                            <?php ($details = $row->propertyDetails()->where(array('is_showed'=>1))->limit(3)->get()); ?>
                                            <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php ($name = $line->detail()->select($locale.'_name as name')->first() ); ?>

                                                <li> <?php if(!empty($line->detail->icon)): ?> <img width="20px" data-src="<?php echo e(asset($line->detail->icon)); ?>" alt=""> <?php endif; ?> <?php echo e($line->value); ?> <?php if(!empty($line->detail->unit)): ?> <?php echo e($line->detail->unit); ?> <?php endif; ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <li style="width: 20px;">
                                                <figure> 
                                                    <?php if($row->action_id == 1 ): ?>
                                                        <span  style="padding: 4px 14px 5px; border-radius: 5px;background-color: #e63355;" class="color-two"><?php echo e(__('web.for-sale')); ?></span>
                                                    <?php elseif( $row->action_id == 2 ): ?>
                                                        <span  style="padding: 4px 14px 5px; border-radius: 5px;background-color: #8333e6;" class="color-two"><?php echo e(__('web.for-rent')); ?></span>
                                                    <?php else: ?>
                                                        <span  style="padding: 4px 14px 5px; border-radius: 5px;background-color: #8333e6;" class="color-two"><?php echo e(__('web.rent-sale')); ?></span>
                                                    <?php endif; ?>
                                                    
                                                </figure>
                                            </li>


                                        </ul>
                                        <h6>$ 2500</h6>
                                    </div>
                                </div>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- <li class="col-md-12">
                                <figure><a href="listing-detail.html"><img src="<?php echo e(asset ('public/frontend/extra-images/listing-list-img2.jpg')); ?>" alt=""><i class="fa fa-link"></i><span class="img-transparent"></span></a></figure>
                                <div class="findhome-listing-list-wrap">
                                    <div class="findhome-listing-list-text">
                                        <h5><a href="listing-detail.html">Morbi Ultrices ac Metus Vitae Consequat Cras Mi</a></h5>
                                        <span><i class="fa fa-map-marker"></i> 8th Ave, New York, NY 10018, USA</span>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum vitae dolor faci sis quam sollicitudin auctor vel sed magna. Aenean pharetra magna in leo vehicu vitae ornare neque scelerisque.</p>
                                    </div>
                                    <div class="findhome-user-post">
                                        <ul class="findhome-listing-option">
                                            <li><a href="listing-detail.html"><i class="fa fa-bed"></i> 03</a></li>
                                            <li><a href="listing-detail.html"><i class="icon-furniture"></i> 02</a></li>
                                            <li><a href="listing-detail.html"><i class="fa fa-area-chart"></i> 250 sq ft</a></li>
                                        </ul>
                                        <h6>$ 2500</h6>
                                    </div>
                                </div>
                            </li> -->
                        </ul>
                        <?php else: ?>
                        <div class="property-listing-header">
                            <h4><span>No Data</span></h4>
                        </div>
                    <?php endif; ?>
                    </div>
                    <?php echo e($data->links('vendor.pagination.frontend-html')); ?>

                </div>

                
                <aside class="col-md-3">
                    <?php echo $__env->make('frontend.layouts.sidebar.related-property', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('frontend.layouts.sidebar.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </aside>
                

            </div>
        </div>
    </div>
    <!--// Main Section \\-->

</div>


      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>