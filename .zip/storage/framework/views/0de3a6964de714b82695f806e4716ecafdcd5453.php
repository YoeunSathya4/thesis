<?php $__env->startSection('section-title', 'Edit Form district'); ?>
<?php $__env->startSection('tab-active-district', 'active'); ?>


<?php $__env->startSection('section-js'); ?>
	<script type="text/JavaScript">
		$(document).ready(function(event){
		
			$('#form').validate({
				modules : 'file',
				submit: {
					settings: {
						inputContainer: '.form-group',
						errorListClass: 'form-tooltip-error'
					}
				}
			}); 
			

		}); 
		
	</script>

	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tab-content'); ?>
<div class="container-fluid">
	<?php echo $__env->make('user.layouts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php ($status = 0); ?>
		<?php ($en_name = ""); ?>
		<?php ($kh_name = ""); ?>
		<?php ($zip_code = ""); ?>
		<?php ($lat = ""); ?>
		<?php ($lng = ""); ?>
       
       	<?php if(Session::has('invalidData')): ?>
            <?php ($invalidData = Session::get('invalidData')); ?>
            <?php ($status = $invalidData['status']); ?>
            <?php ($en_name = $invalidData['en_name']); ?>
            <?php ($kh_name = $invalidData['kh_name']); ?>
            <?php ($zip_code = $invalidData['zip_code']); ?>
            <?php ($lat = $invalidData['lat']); ?>
            <?php ($lng = $invalidData['lng']); ?>

            
       	<?php endif; ?>
	<form id="form" action="<?php echo e(route($route.'.store-district')); ?>" name="form" method="POST"  enctype="multipart/form-data">
			<?php echo e(csrf_field()); ?>

			<?php echo e(method_field('PUT')); ?>

			<input type="hidden" name="province_id" value="<?php echo e($id); ?>">
		<div class="form-group row">
				<label class="col-sm-2 form-control-label" for="kh_name">Title (KH)</label>
				<div class="col-sm-10">
					<input 	id="kh_name"
							name="kh_name"
						   	value = "<?php echo e($kh_name); ?>"
						   	type="text"
						   	placeholder = "enter name in Khmer"
						   	class="form-control"
						   	data-validation="[L>=1, L<=200]"
							 />
							
				</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-2 form-control-label" for="en_name">Title (En)</label>
				<div class="col-sm-10">
					<input 	id="en_name"
							name="en_name"
						   	value = "<?php echo e($en_name); ?>"
						   	type="text"
						   	placeholder = "enter name in English"
						   	class="form-control"
						   	data-validation="[L>=1, L<=200]"
							 />
							
				</div>
			</div>
			
			<div class="form-group row">
				<label class="col-sm-2 form-control-label" for="zip_code">Zip Code</label>
				<div class="col-sm-10">
					<input 	id="zip_code"
							name="zip_code"
						   	value = "<?php echo e($zip_code); ?>"
						   	type="number"
						   	placeholder = "enter zip_code"
						   	class="form-control"
						   	data-validation="[L>=5, L<=10]"
							 />
							
				</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-2 form-control-label" for="lat">Lat</label>
				<div class="col-sm-10">
					<input 	id="lat"
							name="lat"
						   	value = "<?php echo e($lat); ?>"
						   	type="text"
						   	placeholder = "enter lat"
						   	class="form-control"
						   	data-validation="[L>=1, L<=200]"
							 />
							
				</div>
			</div>
			
			<div class="form-group row">
				<label class="col-sm-2 form-control-label" for="lng">Lng</label>
				<div class="col-sm-10">
					<input 	id="lng"
							name="lng"
						   	value = "<?php echo e($lng); ?>"
						   	type="text"
						   	placeholder = "enter lng"
						   	class="form-control"
						   	data-validation="[L>=1, L<=200]"
							 />
							
				</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-2 form-control-label" for="status">Published</label>
				<div class="col-sm-10">
					<div class="checkbox-toggle">
						<input name="status" id="status" type="checkbox"  <?php if($status ==1 ): ?> checked <?php endif; ?> >
						<label onclick="change_active()" for="status"></label>
					</div>
					<input type="hidden" name="status" id="status" value="<?php echo e($status); ?>">
				</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-2 form-control-label"></label>
				<div class="col-sm-10">
					
					<button type="submit" class="btn btn-success"> <fa class="fa fa-plus"></i> Create</button>
				</div>
			</div>
		</form>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($route.'.tab', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>