<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>PI Real Estate</title>
    <link rel="shortcut icon" href="http://localhost/CamCyber/pi_realestate/app/public/frontend/images/favicon.png" type="image/x-icon">

    <!-- Css Files -->
    <link href="<?php echo e(asset ('public/frontend/css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset ('public/frontend/css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset ('public/frontend/css/flaticon.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset ('public/frontend/css/slick-slider.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset ('public/frontend/css/fancybox.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset ('public/frontend/build/mediaelementplayer.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset ('public/frontend/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset ('public/frontend/css/color.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset ('public/frontend/css/responsive.css')); ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i%7CRaleway:100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet"> 
    <?php if($locale=="kh"): ?>
      <link href="https://fonts.googleapis.com/css?family=Hanuman" rel="stylesheet">
      <link href="<?php echo e(asset ('public/frontend/css/kh_laugauges.css')); ?>" rel="stylesheet">
    <?php endif; ?>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
<body>

<body>
  
    <!--// Main Wrapper \\-->
    <div class="findhome-main-wrapper">
        <!--// Header \\-->
        <header id="findhome-header" class="findhome-header-one">
            
            <!--// TopStrip \\-->
            <div class="findhome-top-strip findhome-bgcolor">
                <div class="container">
                    <div class="row">
                        <aside class="col-md-3"></aside>
                        <aside class="col-md-6"></aside>
                        <aside class="col-md-3">
                            <ul class="findhome-strip-info findhome-user-section">

                                <li><a href="<?php echo e(route($defaultData['routeName'], $defaultData['khRouteParamenters'])); ?>">ខ្មែរ</a></li>
                                <li><a href="<?php echo e(route($defaultData['routeName'], $defaultData['enRouteParamenters'])); ?>">EN</a></li>

                            </ul>
                        </aside>
                    </div>
                </div>
            </div>
            <!--// TopStrip \\-->

            <!--// Main Header \\-->
            <div class="findhome-main-header">
                <div class="container">
                    <div class="findhome-header-wrap">
                        <div class="row">
                            <aside class="col-md-2"> <a href="<?php echo e(route('home',['locale'=>$locale])); ?>" class="logo"><img src="<?php echo e(asset ('public/frontend/images/logo.png')); ?>" alt=""></a> </aside>
                            <aside class="col-md-10">
                                <nav class="navbar navbar-default">
                                    <div class="navbar-header">
                                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse-1" aria-expanded="true">
                                            <span class="sr-only">Toggle navigation</span>
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                        </button>
                                    </div>
                                    <div class="collapse navbar-collapse" id="navbar-collapse-1">
                                        <ul class="nav navbar-nav">
                                            <li class="<?php echo $__env->yieldContent('property'); ?>"><a href="<?php echo e(route('property', $locale)); ?>"><?php echo e(__('general.properties')); ?></a></li>
                                            <li class="<?php echo $__env->yieldContent('service'); ?>"><a href="<?php echo e(route('service', $locale)); ?>"><?php echo e(__('general.our-service')); ?></a></li>
                                            <li class="<?php echo $__env->yieldContent('team'); ?>"><a href="<?php echo e(route('team', $locale)); ?>"><?php echo e(__('general.our-team')); ?></a></li>
                                            <li class="<?php echo $__env->yieldContent('news'); ?>"><a href="<?php echo e(route('news', $locale)); ?>"><?php echo e(__('general.news')); ?></a></li>
                                            <li class="<?php echo $__env->yieldContent('about-us'); ?>"><a href="<?php echo e(route('about-us', $locale)); ?>"><?php echo e(__('general.about-yao')); ?></a></li>
                                            
                                        </ul>

                                        
                                    </div>
                                </nav>
                                <a href="tel:(+855) 77 813 111"" class="findhome-simple-btn findhome-color findhome-bordercolor">Call Us (+855) 416617</a>
                                 
                                <!-- <a href="<?php echo e(route('customer', $locale)); ?>" class="findhome-simple-btn findhome-color findhome-bordercolor"><?php echo e(__('general.customer-require')); ?></a> -->
                            </aside>
                        </div>
                    </div>
                </div>
            </div>
            <!--// Main Header \\-->

        </header>
        <!--// Header \\-->

    <!--// Main Banner \\-->

<?php echo $__env->yieldContent('content'); ?>

 <!--// Footer \\-->
        <footer id="findhome-footer" class="findhome-footer-one">
            <div class="findhome-footer-strip">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="findhome-footer-strip-twitter">
                                <i class="fa fa-twitter"></i>
                                <div class="findhome-footer-strip-slider">
                                    <?php ($related_news = $defaultData['related_news']); ?>
                                    <?php $__currentLoopData = $related_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="findhome-footer-strip-layer">
                                        <p> <?php echo e($row->description); ?> <a href="<?php echo e(route('news-detail',['locale'=>$locale,'slug'=>$row->slug])); ?>"><?php echo e($row->title); ?></a></p>
                                        <time datetime="2008-02-14 20:00">~ <?php echo e(Carbon\Carbon::parse($row->created_dt)->format('d')); ?> <?php echo e(Carbon\Carbon::parse($row->created_dt)->format('M')); ?> <?php echo e(Carbon\Carbon::parse($row->created_dt)->format('Y')); ?></time>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="findhome-footer-widget">
                <span class="footer-widget-transparent"></span>
                <div class="container">
                    <div class="row">


                        <!--// Widget Newsletter \\-->
                        <aside class="col-md-6 widget widget_newsletter">
                            <h2 class="findhome-footer-title"><?php echo e(__('general.sign-up-for-our-newsletter')); ?></h2>
                            <p><?php echo e(__('general.latest-properties')); ?></p>
                        </aside>

                        <aside class="col-md-6 widget widget_newsletter">
                            <form method="post" id="newsletter-form" class="newsletter-form">
                                <label><?php echo e(__('general.your-email')); ?>:</label> 
                                <input placeholder="<?php echo e(__('general.type-here')); ?>" tabindex="0" type="email" id="form-email" name="email">
                                <label class="banner-submit"><input value="<?php echo e(__('general.subcribe-now')); ?>" class="findhome-bgcolor" type="submit"></label>
                            </form>
                        </aside>
                        <!--// Widget Newsletter \\-->

                        <div class="col-md-12">
                            <div class="findhome-copyright">
                                <a href="index.html#" class="findhome-back-top"><i class="fa fa-angle-up"></i></a>
                                <p><i class="fa fa-copyright"></i> <?php echo e(__('general.copyright')); ?></p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

        </footer>
        <!--// Footer \\-->

  <div class="clearfix"></div>
</div>

<!-- jQuery (necessary for JavaScript plugins) -->
<script type="text/javascript" src="<?php echo e(asset ('public/frontend/script/jquery.js')); ?>"></script>
<script src="<?php echo e(asset ('public/frontend/script/jquery-ui.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset ('public/frontend/script/bootstrap.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset ('public/frontend/script/slick.slider.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset ('public/frontend/script/fancybox.pack.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset ('public/frontend/script/numscroller.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset ('public/frontend/script/progressbar.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset ('public/frontend/build/mediaelement-and-player.min.js')); ?>"></script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>
<script type="text/javascript" src="<?php echo e(asset ('public/frontend/script/functions.js')); ?>"></script>
<?php echo $__env->yieldContent('appbottomjs'); ?>
<?php echo $__env->yieldContent('property-js'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
    <script>
    $(document).ready(function() {
      $("#newsletter-form").submit(function(event){
        event.preventDefault();
        email = $("#form-email").val();

        //alert(phone);
            if(email != ""){
                if(validateEmail(email)){
                    
                    $.ajax({
                      url: "<?php echo e(route('submit-newsletter', ['locale'=>$locale])); ?>",
                      type: 'PUT',
                      data: {email:email},
                      success: function( response ) {
                         email = $("#form-email").val('');
                         toastr.success("<?php echo e(__('general.contact-successful-sent')); ?>");
                         //email = $("#email_newsleter").val('');
                      },
                      error: function( response ) {
                         toastr.warning("<?php echo e(__('general.sorry')); ?>");
                      }
                      
                  });
                    }else{
                        error(event, "email", '<?php echo e(__('general.incorrectemail')); ?>');
                            $('#form-email').focus();
                    }
                }else{
                    error(event, "email", '<?php echo e(__('general.erroremail')); ?>.');
                    $('#form-email').focus();
                }
            
        })

    });
    
    function validateEmail(email) { 
        var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    }
    function validatePhone(phone) {
        return phone.match(/(^[00-9].{8}$)|(^[00-9].{9}$)/);
    }
    function error(event, obj, msg){
      event.preventDefault();
      toastr.error(msg);
      $("#"+obj).focus();
    }
   
  </script>
<script>
    function init() {
    var imgDefer = document.getElementsByTagName('img');
    for (var i=0; i<imgDefer.length; i++) {
    if(imgDefer[i].getAttribute('data-src')) {
    imgDefer[i].setAttribute('src',imgDefer[i].getAttribute('data-src'));
    } } }
    window.onload = init;
</script>
</body>
</html>