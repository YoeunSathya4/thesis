<?php $__env->startSection('title', 'About Us'); ?>
<?php $__env->startSection('about-us', 'active'); ?>

<?php $__env->startSection('appbottomjs'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="findhome-subheader">
    <div class="findhome-subheader-image" style="background-image: url(<?php echo e(asset(showBanner('about-page'))); ?>);">
        <span class="findhome-dark-transparent"></span>
        <div class="container">
            <div class="row">
                <div class="col-md-12">

                </div>
            </div>
        </div>
    </div>
    <div class="findhome-breadcrumb">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <ul>
                        <li><a href="<?php echo e(route('home',$locale)); ?>"><?php echo e(__('general.home')); ?></a></li>
                        <li class="findhome-color"><?php echo e(__('general.about-yao')); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>  

<div class="findhome-main-content">

	<!--// Main Section \\-->
	<div class="findhome-main-section findhome-about-usfull">
		<div class="container">
			<div class="row text-center">
				
				<div class="col-md-12">
                    <div class="findhome-about-us">
                        <div class="findhome-fancy-title">
                            <h2 class="findhome-color"><?php echo e(__('general.about-yao')); ?></h2>
                            <div class="findhome-fancy-shape"><span><small></small></span></div>
                        </div>
                        <p><?php echo $content->content; ?></p>
                        <div><br></div>
                        <div class="col-md-6">
                            <div>
								<h3 class="findhome-color"><?php echo e(__('web.vision')); ?></h3>
								<p class="paddingb5"><?php echo $vision->content; ?></p>
                            </div>
                            <br>
                        </div>
                        <div class="col-md-6">
                            <div>
								<h3 class="findhome-color"><?php echo e(__('web.mission')); ?></h3>
								<p><?php echo $mission->content; ?></p>
                            </div>
                            <br>
                        </div>
                        <div class="findhome-fancy-title">
                            <h2 class="findhome-color"><?php echo e(__('general.contact-us')); ?></h2>
                            <div class="findhome-fancy-shape"><span><small></small></span></div>
                        </div>
                        <p><?php echo e(__('web.address')); ?>: <?php echo e(__('web.address-detail')); ?></p>

                        <div class="col-md-6">
                            <div>
								<h3 class="findhome-color"><?php echo e(__('general.email')); ?></h3>
								<p><?php echo e(__('web.email-address')); ?>: info@pirealty.com</p>
                            </div>
                            <br>
                        </div>
                        <div class="col-md-6">
                            <div>
								<h3 class="findhome-color"><?php echo e(__('general.phone')); ?></h3>
								<p>+855 (0)69 370 087</p>
                            </div>
                            <br>
                        </div>
                        <div class="col-md-6">
                            <div>
								<h3 class="findhome-color"><?php echo e(__('web.facebook')); ?></h3>
								<p><?php echo e(__('web.facebook')); ?>: facebook.com/PIrealty</p>
                            </div>
                            <br>
                        </div>
                        <div class="col-md-6">
                            <div>
								<h3 class="findhome-color"><?php echo e(__('web.working-hours')); ?></h3>
								<p class="paddingb5"><?php echo e(__('web.monday-friday')); ?>:8:00am - 5:00pm</p>
                                <p><?php echo e(__('web.saturday')); ?>: 8:00am - 12:00pm</p>
                                <p><?php echo e(__('web.sunday')); ?>:<?php echo e(__('web.closed')); ?></p>
                            </div>

                            <br>
                        </div>
                    </div>
                </div>
			</div>
		</div>
	</div>
	<!--// Main Section \\-->
</div>

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>