
<table id="seleted-table" class="table pop">
	<thead>
		<th width=10%>No.</th><th>Name.</th><th width=8%>.</th>
	</thead>
	<tbody>
		<?php ( $i=1 ); ?>
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($i++); ?></td><td><?php echo e($row->en_name); ?></td><td><i onclick="remove(<?php echo e($row->id); ?>)" class="fa fa-times"></i></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
