<?php $__env->startSection('section-title', 'Team'); ?>
<?php $__env->startSection('hide-btn-back', 'display:none'); ?>
<?php $__env->startSection('section-css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('section-js'); ?>
	<script type="text/JavaScript">
			function updateStatus(id){
		     	thestatus = $('#status-'+id);
		     	active = thestatus.attr('data-value');

		     	if(active == 1){
		     		active = 0;
		     		thestatus.attr('data-value', 1);
		     	}else{
		     		active = 1;
		     		thestatus.attr('data-value', 0);
		     	}

		     	$.ajax({
			        url: "<?php echo e(route($route.'.update-status')); ?>",
			        method: 'POST',
			        data: {id:id, active:active },
			        success: function( response ) {
			            if ( response.status === 'success' ) {
			            	swal("Nice!", response.msg ,"success");
			            	
			            }else{
			            	swal("Error!", "Sorry there is an error happens. " ,"error");
			            }
			        },
			        error: function( response ) {
			           swal("Error!", "Sorry there is an error happens. " ,"error");
			        }
				});
			}
	</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section-content'); ?>
	<?php if(sizeof($data) > 0): ?>
		<div class="table-responsive">
			<table id="table-edit" class="table table-bordered table-hover">
				<thead>
					<tr>
						<th>#</th>
						<th>Name</th>
						<th>Position</th>
						<th>Image</th>
						<th>Published</th>
						<th>Updated Date</th>
						<th></th>
					</tr>
				</thead>
				<tbody>

					<?php ($i = 1); ?>
					<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($i++); ?></td>
							<td><?php echo e($row->en_title); ?></td>
							<td><?php echo e($row->en_position); ?></td>
							<td>
								<img src="<?php echo e(asset($row->image)); ?>" class="img img-responsive" />
							</td>
							<td>
								<div class="checkbox-toggle">
							        <input onclick="updateStatus(<?php echo e($row->id); ?>)" type="checkbox" id="status-<?php echo e($row->id); ?>" <?php if($row->is_published == 1): ?> checked data-value="1" <?php else: ?> data-value="0" <?php endif; ?> >
							        <label for="status-<?php echo e($row->id); ?>"></label>
						        </div>
							</td>
							<td><?php echo e($row->updated_at); ?></td>
							<td style="white-space: nowrap; width: 1%;">
								<div class="tabledit-toolbar btn-toolbar" style="text-align: left;">
		                           	<div class="btn-group btn-group-sm" style="float: none;">
		                           		<a href="<?php echo e(route($route.'.edit', $row->id)); ?>" class="tabledit-edit-button btn btn-sm btn-success" style="float: none;"><span class="glyphicon glyphicon-pencil"></span></a>
		                           		<a href="#" onclick="deleteConfirm('<?php echo e(route($route.'.trash', $row->id)); ?>', '<?php echo e(route($route.'.list')); ?>')" class="tabledit-delete-button btn btn-sm btn-danger" style="float: none;"><span class="glyphicon glyphicon-trash"></span></a>
		                           	</div>
		                       </div>
		                    </td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div >
	<?php else: ?>
		<span>No Data</span>
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($route.'.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>