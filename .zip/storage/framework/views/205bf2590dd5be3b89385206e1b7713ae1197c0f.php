<?php if(sizeof($data) > 0): ?>
<table id="table-edit" class="table table-bordered table-hover">
	<thead>
		<tr>
			<th>No</th>
			<th>Name</th>
			
		</tr>
	</thead>	
	<tbody>
		<?php ($i = 1); ?>
		<?php ($j=0); ?>
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($i++); ?></td>
				<td>
					<div class="checkbox">
						<input type="checkbox" id="customer-<?php echo e($row->id); ?>" class="customerExisting" onclick="selectCustomer(<?php echo e($row->id); ?>)">
						<label for="customer-<?php echo e($row->id); ?>"><?php echo e($row->name); ?></label>
					</div>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>

<?php else: ?>
	<span>No Data</span>
<?php endif; ?>