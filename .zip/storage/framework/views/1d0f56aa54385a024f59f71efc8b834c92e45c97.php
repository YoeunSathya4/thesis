<?php $__env->startSection('section-title', 'Note'); ?>
<?php $__env->startSection('tab-active-note', 'active'); ?>
<?php $__env->startSection('tab-css'); ?>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('imageuploadjs'); ?>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tab-js'); ?>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tab-content'); ?>
	
	<div>
		<div class="col-md-12">
			<?php if(checkPermision($route.'.create-note')): ?><a style="float: right;margin-bottom: 10px;margin-top: -10px;" href="<?php echo e(route($route.'.create-note',$id)); ?>"  class="tabledit-delete-button btn btn-sm btn-primary" style="float: none;"><span class="fa fa-plus"></span></a>	<?php endif; ?>
		</div>
	</div><!--.row-->
	<?php if(count($data)>0): ?>
	<div class="table-responsive">
		<table id="table-edit" class="table table-bordered table-hover">
			<thead>
				<tr>
					<th>#</th>
					<th>Note</th>
					<th>Notifiy</th>
					<th>Date</th>
					<th></th>
				</tr>
			</thead>
			<tbody>

				<?php ($i = 1); ?>
				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($i++); ?></td>
						<td><?php echo e($row->note); ?></td>
						<td>
								<div class="checkbox-toggle">
							        <input  type="checkbox" id="status-<?php echo e($row->id); ?>" <?php if($row->is_notified == 1): ?> checked data-value="1" <?php else: ?> data-value="0" <?php endif; ?> >
							        <label for="status-xx"></label>
						        </div>
							</td>
						<td><?php echo e($row->date); ?></td>
						<td style="white-space: nowrap; width: 1%;">
							<div class="tabledit-toolbar btn-toolbar" style="text-align: left;">
	                           	<div class="btn-group btn-group-sm" style="float: none;">
	                           		<?php if(checkPermision($route.'.edit-note')): ?><a href="<?php echo e(route($route.'.edit-note', ['id'=>$id,'note_id'=>$row->id])); ?>" class="tabledit-edit-button btn btn-sm btn-success" style="float: none;"><span class="fa fa-eye"></span></a><?php endif; ?>
	                           		<?php if(checkPermision($route.'.trash-note')): ?><a href="#" onclick="deleteConfirm('<?php echo e(route($route.'.trash-note', $row->id)); ?>', '<?php echo e(route($route.'.notes',$id)); ?>')" class="tabledit-delete-button btn btn-sm btn-danger" style="float: none;"><span class="glyphicon glyphicon-trash"></span></a><?php endif; ?>
	                           	</div>
	                       </div>
	                    </td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div >
	<?php else: ?>
	No Notes
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($route.'.tab', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>