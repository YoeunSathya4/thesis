<?php $__env->startSection('active-main-menu-restaurant', 'opened'); ?>
<?php $__env->startSection('title'); ?>
	Restaurant: <?php echo $__env->yieldContent('section-title'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('appheadercss'); ?>
	<?php echo $__env->yieldContent('section-css'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('appbottomjs'); ?>
	<?php echo $__env->yieldContent('section-js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
	<header class="page-content-header">
		<div class="container-fluid">
			<div class="tbl">
				<div class="tbl-row">
					<div class="tbl-cell">
						<h3>Restaurant </h3> 
					</div>
					<div class="tbl-cell tbl-cell-action">
						<a href="<?php echo e(route('cp.restaurant.index')); ?>"  class="tabledit-delete-button btn btn-sm btn-primary" style="float: none;  <?php echo $__env->yieldContent('hide-btn-back'); ?>  "><span class="fa fa-arrow-left"></span></a>
						<a href="<?php echo e(route('cp.restaurant.create')); ?>"  class="tabledit-delete-button btn btn-sm btn-primary" style="float: none;"><span class="fa fa-plus"></span></a>
					</div>
				</div>
			</div>
		</div>
	</header>
	<div class="container-fluid">
		<div class="box-typical box-typical-padding">
			<?php echo $__env->yieldContent('section-content'); ?>
		</div>	
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('cp.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>