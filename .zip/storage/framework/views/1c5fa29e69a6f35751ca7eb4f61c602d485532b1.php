<?php $__env->startSection('section-title', 'Create New Property'); ?>
<?php $__env->startSection('section-css'); ?>
	<style type="text/css">
		.margin-top-10{
			margin-top:10px;
		}
		
	</style>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('section-js'); ?>
	<script type="text/JavaScript">
		$(document).ready(function(event){
		
			$('#form').validate({
				modules : 'file',
				submit: {
					settings: {
						inputContainer: '.form-group',
						errorListClass: 'form-tooltip-error'
					}
				}
			}); 

			
			$("#province-id").change(function(){
				codeGenerator()
			})
			
		}); 

	
		
	</script>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('section-content'); ?>
	<div class="container-fluid">
		
		<?php echo $__env->make('user.layouts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php if(isset($_GET['listing_code'])): ?>
			<div class="alert alert-aquamarine alert-no-border alert-close alert-dismissible fade in" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">×</span>
				</button>
				<strong>Hey!</strong><br>
				You have just created a property which has listing code :<b><?php echo e($_GET['listing_code']); ?></b>
			</div>
		<?php endif; ?>

		<?php ($action_id = 0); ?>
		<?php ($type_id = 0); ?>
		
		<?php ($province_id = 0); ?>
		<?php ($cadaster_id = 1); ?>

		<?php ($kh_name = ""); ?>
		<?php ($en_name = ""); ?>

		<?php ($kh_excerpt = ""); ?>
		<?php ($en_excerpt = ""); ?>

		<?php ($kh_description = ""); ?>
		<?php ($en_description = ""); ?>

       	<?php if(Session::has('invalidData')): ?>
            <?php ($invalidData = Session::get('invalidData')); ?>

			<?php ($action_id = $invalidData['action_id']); ?>
			<?php ($type_id = $invalidData['type_id']); ?>
			<?php ($province_id = $invalidData['province_id']); ?>
			
			<?php ($cadaster_id = $invalidData['cadaster_id']); ?>

		
            <?php ($listing_code = $invalidData['listing_code']); ?>
            <?php ($kh_name = $invalidData['kh_name']); ?>
            <?php ($en_name = $invalidData['en_name']); ?>

            <?php ($kh_nexcerpt = $invalidData['kh_excerpt']); ?>
            <?php ($en_excerpt = $invalidData['en_excerpt']); ?>
            <?php ($kh_description = $invalidData['kh_description']); ?>
            <?php ($en_description = $invalidData['en_description']); ?>

       	<?php endif; ?>
		<form id="form" action="<?php echo e(route('user.property.property.store')); ?>" name="form" method="POST"  enctype="multipart/form-data">
			<?php echo e(csrf_field()); ?>

			<?php echo e(method_field('PUT')); ?>


			
			<div class="form-group row">
				<label for="action-id" class="col-sm-2 form-control-label">Action</label>
				<div class="col-sm-10">
					<select id="action-id" name="action-id" class="form-control">
						<?php if($action_id != 0): ?>
							<?php ( $lable = DB::table('actions')->find($action_id) ); ?>
							<?php if( sizeof($lable) == 1 ): ?>
								<option value="<?php echo e($lable->id); ?>" ><?php echo e($lable->en_name); ?></option>
							<?php endif; ?>
						<?php endif; ?>
						<option value="0" >Select Action</option>
						<?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($row->id != $action_id): ?>
								<option value="<?php echo e($row->id); ?>" ><?php echo e($row->name); ?></option>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			</div>
			<div class="form-group row">
				<label for="type-id" class="col-sm-2 form-control-label">Type</label>
				<div class="col-sm-10">
					<select id="type-id" name="type-id" class="form-control">
						<?php if($type_id != 0): ?>
							<?php ( $lable = DB::table('types')->find($type_id) ); ?>
							<?php if( sizeof($lable) == 1 ): ?>
								<option value="<?php echo e($lable->id); ?>" ><?php echo e($lable->en_name); ?> (<?php echo e($lable->abbre); ?>)</option>
							<?php endif; ?>
						<?php endif; ?>
						<option value="0" >Select Type</option>
						<?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($row->id != $type_id): ?>
								<option value="<?php echo e($row->id); ?>" ><?php echo e($row->name); ?> (<?php echo e($row->abbre); ?>)</option>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			</div>
			
			<div class="form-group row">
				<label for="province-id" class="col-sm-2 form-control-label">Province</label>
				<div class="col-sm-10">
					<select id="province-id" name="province-id" class="form-control">
						<?php if($province_id != 0): ?>
							<?php ( $lable = DB::table('provinces')->find($province_id) ); ?>
							<?php if( sizeof($lable) == 1 ): ?>
								<option value="<?php echo e($lable->id); ?>" ><?php echo e($lable->en_name); ?> (<?php echo e($lable->abbre); ?>)</option>
							<?php endif; ?>
						<?php endif; ?>
						<option value="0" >Select Province</option>
						<?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($row->id != $province_id): ?>
								<option value="<?php echo e($row->id); ?>" ><?php echo e($row->name); ?> (<?php echo e($row->abbre); ?>)</option>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			</div>

			

			<div class="form-group row">
				<label class="col-sm-2 form-control-label" for="kh_content">Cadaster Type</label>
				<div class="col-sm-1">
					<div class="radio  margin-top-10">
						<input type="radio" name="cadaster_id" id="radio-1" value="1" <?php if($cadaster_id == 1 ): ?> checked <?php endif; ?> >
						<label for="radio-1">Soft</label>
					</div>
				</div>
				<div class="col-sm-1">
					<div class="radio  margin-top-10">
						<input type="radio" name="cadaster_id" id="radio-2" value="2" <?php if($cadaster_id == 2 ): ?> checked <?php endif; ?> >
						<label for="radio-2">Hard</label>
					</div>
				</div>
				<div class="col-sm-1">
					<div class="radio  margin-top-10">
						<input type="radio" name="cadaster_id" id="radio-3" value="3" <?php if($cadaster_id == 3 ): ?> checked <?php endif; ?> >
						<label for="radio-3">N/A</label>
					</div>
				</div>
			</div>
			
			<div class="form-group row">
				<label class="col-sm-2 form-control-label" >Name (Kh)</label>
				<div class="col-sm-10">
					<input 	id="kh-name"
							name="kh-name"
							value = "<?php echo e($kh_name); ?>"
							type="text"
							placeholder = "Name of property in Khmer"
							class="form-control" />
				</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-2 form-control-label" >Name (En)</label>
				<div class="col-sm-10">
					<input 	id="en-name"
							name="en-name"
							value = "<?php echo e($en_name); ?>"
							type="text"
							placeholder = "Name of property in English"
						   	class="form-control"
						   	data-validation="[L>=5, L<=200]" />
				</div>
			</div>
			<?php if(checkPermision('user.property.staff.add')): ?>
			<div class="form-group row">
				<label for="staff-id" class="col-sm-2 form-control-label">Staff In Charge</label>
				<div class="col-sm-5">
					<select id="staff-id" name="staff-id" class="form-control">
						<option value="0" >Select Staff</option>
						<?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($row->id); ?>" ><?php echo e($row->name); ?> - <?php echo e($row->position); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				<div class="col-sm-5">
					<select id="role-id" name="role-id" class="form-control">
						<option value="0" >Select Role</option>
						<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($row->id); ?>" ><?php echo e($row->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			</div>
			<?php endif; ?>
		
			
			<div class="form-group row">
				<label class="col-sm-2 form-control-label"></label>
				<div class="col-sm-10">
					<button type="submit" class="btn btn-success"> <fa class="fa fa-plus"></i> Create</button>
				</div>
			</div>
		</form>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make($route.'.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>