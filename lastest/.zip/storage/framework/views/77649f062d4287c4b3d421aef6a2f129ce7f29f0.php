<?php $__env->startSection('title', 'PROMOTION | KHEMARAKSMEY'); ?>
<?php $__env->startSection('promotion', 'active'); ?>

<?php $__env->startSection('appbottomjs'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <!-- breadcrumb -->
    <div class="parallax-window inner-banner tc-padding overlay-dark" data-parallax="scroll" data-image-src="<?php echo e(asset('public/frontend/images/banner.jpg')); ?>">
        <div class="container">
            <div class="inner-page-heading h-white style-2">
                <h2><?php echo e(__('general.promotion')); ?></h2>
            </div>
        </div>
    </div>


    		<div class="container" style="padding-top: 20px;">
                <div class="tc-padding-bottom">
                    <div class="row">
                		<?php $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Column -->
                        <div class="col-lg-4 col-xs-12 r-full-width" >
                            <div class="address-column ">
                                <img class="promotion-css"  src="<?php echo e(asset ('public/uploads/promotion/image/'.$row->image)); ?>" alt="">
                                <strong id="promotion-text"><?php echo e($row->title); ?></strong>
                                <p><?php echo $row->description; ?></p>
                            </div>
                        </div>
                        <!-- Column -->

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <?php echo e($promotions->links('vendor.pagination.frontend-html')); ?>

                </div>
            </div>
    
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>