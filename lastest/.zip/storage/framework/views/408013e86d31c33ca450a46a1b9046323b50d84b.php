<?php $__env->startSection('title', 'KHEMARAKSMEY | Porfile'); ?>



<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset ('public/cp/css/plugin/fileinput/fileinput.min.css')); ?>" media="all" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset ('public/cp/css/plugin/fileinput/theme.css')); ?>" media="all" rel="stylesheet" type="text/css"/>
    <!-- some CSS styling changes and overrides -->
    <style>
        .kv-avatar .file-preview-frame,.kv-avatar .file-preview-frame:hover {
            margin: 0;
            padding: 0;
            border: none;
            box-shadow: none;
            text-align: center;
        }
        .kv-avatar .file-input {
            display: table-cell;
            max-width: 220px;
        }
        #profileMenu{
        	color: #ffffff;font-size: 18px;text-align: center;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('appbottomjs'); ?>
<script type="text/javascript" src="<?php echo e(asset ('public/cp/js/plugin/fileinput/fileinput.min.js')); ?>" type="text/javascript"></script>
    <script type="text/javascript" src="<?php echo e(asset ('public/cp/js/plugin/fileinput/theme.js')); ?>" type="text/javascript"></script>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Event List -->
		<div class="tc-padding">
			<div class="container">
				<div class="row">
					<!-- Aside -->
					<aside style="background: #f16162;" class="col-lg-3 col-md-4 col-xs-12 pull-left pull-none">

						<!-- Aside Widget -->
						<div class="aside-widget">
							<h6 style="padding-top: 20px; font-size: 20px; color: #ffffff;"> <b> <?php echo e(__('general.profile-menu')); ?> </b></h6>
							<ul class="s-arthor-list">
								
								<li class="<?php echo $__env->yieldContent('my-profile'); ?>">
									<a id="hover-id" href="<?php echo e(route('profile',$locale)); ?>">
									<h6 id="profileMenu"><?php echo e(__('general.my-profile')); ?></h6>
									</a>
								</li>
								<li>
									<a  href="#">
										<h6 id="profileMenu"><?php echo e(__('general.favorite-product')); ?></h6>
									</a>
								</li>
								<li class="<?php echo $__env->yieldContent('panding-order'); ?>">
									<a  href="<?php echo e(route('panding-order',$locale)); ?>">
										<h6 id="profileMenu"><?php echo e(__('general.panding-order')); ?></h6>
									</a>
								</li>
								<li class="<?php echo $__env->yieldContent('order-history'); ?>">
									<a  href="<?php echo e(route('order-history',$locale)); ?>">
										<h6 id="profileMenu"><?php echo e(__('general.order-history')); ?></h6>
									</a>
								</li>
								
							</ul>
						</div>
						<!-- Aside Widget -->

					</aside>
					<!-- Aside -->

					<?php echo $__env->yieldContent('profile'); ?>

					

					
					
				</div>
			</div>
		</div>
		<!-- Event List -->
    
      		<style type="text/css">
      			.profile-active{
      				background: #2e3192;
    				padding: 5px;
      			}
      			a:hover{
      				    color: #0082c6;
    					text-decoration: none;
      			}
      		</style>
      		<!-- Contant Holder -->  
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>