<?php $__env->startSection('title', 'PRODUCT | KHEMARAKSMEY'); ?>
<?php $__env->startSection('product', 'active'); ?>

<?php $__env->startSection('appbottomjs'); ?>
	<script type="text/javascript"> 
		/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
		var dropdown = document.getElementsByClassName("dropdown-btn");
		var i;

		for (i = 0; i < dropdown.length; i++) {
		  dropdown[i].addEventListener("click", function() {
		    this.classList.toggle("active");
		    var dropdownContent = this.nextElementSibling;
		    if (dropdownContent.style.display === "block") {
		      dropdownContent.style.display = "none";
		    } else {
		      dropdownContent.style.display = "block";
		    }
		  });
		}
	</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
       <!-- breadcrumb -->
    <div class="parallax-window inner-banner tc-padding overlay-dark" data-parallax="scroll" data-image-src="<?php echo e(asset('public/frontend/images/banner.jpg')); ?>">
        <div class="container">
            <div class="inner-page-heading h-white style-2">
                <h2><?php echo e(__('general.product')); ?></h2>
                <h4><?php echo e(__('general.page')); ?>:<?php if(isset($appends['category_name'])): ?> <?php echo e($appends['category_name']); ?> <?php endif; ?> <?php if(isset($appends['sub_category_name'])): ?> -> <?php echo e($appends['sub_category_name']); ?> <?php endif; ?> <?php if(isset($appends['sub_sub_category_name'])): ?> -> <?php echo e($appends['sub_sub_category_name']); ?> <?php endif; ?></h4>
            </div>
        </div>
    </div>
<!-- Breadcrumb -->

 <!-- Blog List -->
        <div class="tc-padding">
            <div class="container">

                <div class="row">
                    
                    <!-- Content -->
                    <div style="padding-bottom: 25px;" class="col-lg-3 col-md-3 col-xs-12">

	         			<div class="sidenav">
	         			<?php $__currentLoopData = $defaultData['navbar_menu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php if( count( $menu['subCategories'] ) == 0 ): ?>
						  <a href="<?php echo e(route('product', $locale)); ?>?category=<?php echo e($menu['id']); ?>"><?php echo e($menu['name']); ?></a>
						  <?php elseif( count( $menu['subCategories'] ) > 1 ): ?>
						  		<button class="dropdown-btn"><?php echo e($menu['name']); ?> 
							    <i class="fa fa-caret-down"></i>
							  </button>
							   <div class="dropdown-container">
							   	<?php $__currentLoopData = $menu['subCategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							   <!-- 	<a href="#about"><?php echo e($subCategory['name']); ?></a> -->
								   

								   <?php $__currentLoopData = $defaultData['navbar_tab_menu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                           <?php if( count( $menu_tab['subSubCategories'] ) == 0 ): ?>
									  <a href="<?php echo e(route('product', $locale)); ?>?category=<?php echo e($menu['id']); ?>&subcategory=<?php echo e($menu_tab['id']); ?>"><?php echo e($menu_tab['name']); ?></a>
									  <?php elseif( count( $menu_tab['subSubCategories'] ) > 1 ): ?>
									  		<button class="dropdown-btn"><?php echo e($menu_tab['name']); ?> 
										    <i class="fa fa-caret-down"></i>
										  </button>
										   <div class="dropdown-container">
										   	<?php $__currentLoopData = $menu_tab['subSubCategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subSubCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										   	<a href="<?php echo e(route('product', $locale)); ?>?category=<?php echo e($menu['id']); ?>&subcategory=<?php echo e($menu_tab['id']); ?>&maincategory=<?php echo e($subSubCategory['id']); ?>"><?php echo e($subSubCategory['name']); ?></a>
											   

											   

										    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										   
										  </div>
									<?php endif; ?>
			                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	

							    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							   
							  </div>
						<?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
						  <!-- <a href="#services">Services</a>
						  <a href="#clients">Clients</a>
						  <a href="#contact">Contact</a>
						  <button class="dropdown-btn">Dropdown 
						    <i class="fa fa-caret-down"></i>
						  </button>
						  <div class="dropdown-container">
						    <a href="#">Link 1</a>
						    <a href="#">Link 2</a>
							   <button class="dropdown-btn">Dropdown 
							    <i class="fa fa-caret-down"></i>
							  </button>
							   <div class="dropdown-container">
							    <a href="#">Link 1</a>
							    <a href="#">Link 2</a>
							    <a href="#">Link 3</a>
							  </div>
						    <a href="#">Link 3</a>
						  </div>
						  <a href="#contact">Search</a> -->
						</div>	
                    </div>
                    <!-- Content -->

                   <!-- Content -->
                    <div class="col-lg-9 col-md-9 col-xs-12">
                    			<!-- <?php if(Session::has('successs')): ?>
                    				<div id="charge-message" class="alert alert-success">
                    					<?php echo e(Session::get('success')); ?>

                    				</div>
                    				
                    			<?php endif; ?> -->
                    			<?php if($data != ''): ?>
                    			<?php $__currentLoopData = $data->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="row">
                                        <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-3">
                                            <div class="s-product">
                                                <div class="s-product-img">
                                                    <img class="product-css" src="<?php echo e(asset ('public/uploads/product/image/'.$product->image)); ?>" alt="">
                                                    <div class="s-product-hover">
                                                        <div class="position-center-x">
                                                            <a class="btn-1 sm shadow-0" data-toggle="modal" href="<?php echo e(route('add-to-cart',['locale'=>$locale, 'id'=>$product->id])); ?>"><span class="fa fa-shopping-cart"></span> <?php echo e(__('general.add-to-cart')); ?></a>
                                                         
                                                            <a class="btn-1 sm shadow-0" data-toggle="modal" href="<?php echo e(route('product-detail',['locale'=>$locale, 'slug'=>$product->slug])); ?>"><?php echo e(__('general.quick-view')); ?></a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <h6><a href="<?php echo e(route('product-detail',['locale'=>$locale, 'slug'=>$product->slug])); ?>"><?php echo e($product->name); ?></a></h6>
                                                <span><b>Price:</b> $<?php echo e($product->unit_price); ?></span>
                                            </div>
                                        </div>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       			<?php else: ?>
                       				<h3><?php echo e(__('general.no-data-here')); ?></h3>
                       			<?php endif; ?>
                        
                    </div>
                    <!-- Content -->


                </div>
            </div>
        </div>
        <!-- Blog List -->

    
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>