@extends('frontend/layouts.master')

@section('title', 'Search')
@section('service', 'active')

@section ('appbottomjs')
@endsection

@section ('content')
    
@endsection