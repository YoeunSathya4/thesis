<?php $__env->startSection('title', 'KHEMARAKSMEY | Favorite Product'); ?>
<?php $__env->startSection('favorite-product', 'profile-active'); ?>


<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset ('public/cp/css/plugin/fileinput/fileinput.min.css')); ?>" media="all" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset ('public/cp/css/plugin/fileinput/theme.css')); ?>" media="all" rel="stylesheet" type="text/css"/>
    <!-- some CSS styling changes and overrides -->
    <style>
        .kv-avatar .file-preview-frame,.kv-avatar .file-preview-frame:hover {
            margin: 0;
            padding: 0;
            border: none;
            box-shadow: none;
            text-align: center;
        }
        .kv-avatar .file-input {
            display: table-cell;
            max-width: 220px;
        }
        #profileMenu{
        	color: #ffffff;font-size: 18px;text-align: center;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('appbottomjs'); ?>
<script type="text/javascript" src="<?php echo e(asset ('public/cp/js/plugin/fileinput/fileinput.min.js')); ?>" type="text/javascript"></script>
    <script type="text/javascript" src="<?php echo e(asset ('public/cp/js/plugin/fileinput/theme.js')); ?>" type="text/javascript"></script>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('profile'); ?>
     <!-- Content -->
					<div class="col-lg-9 col-md-8 col-xs-12 pull-right pull-none">
						<?php if(count($favorites) > 0): ?>
						<div class="panel panel-default">
			                <div class="panel-heading">
			                    <h3 class="panel-title"><strong><?php echo e(__('general.favorite-product')); ?></strong></h3>
			                </div>
			                <div class="panel-body">
			                    <div class="table-responsive">
			                        <table class="table table-condensed">
			                            <thead>
			                                <tr>
			                                    <td><strong><?php echo e(__('general.name')); ?></strong></td>
			                                    
			                                    <td class="text-right"></td>
			                                    
			                                </tr>
			                            </thead>
			                            <tbody>
			                                <!-- foreach ($order->lineItems as $line) or some such thing here -->
			                                <?php $__currentLoopData = $favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                                <tr>
			                                    <td><?php echo e($row->product->productName); ?> </td>
			                                    <td class="text-right"> <a href="<?php echo e(route('buy',['locale'=>$locale, 'id'=>$row->product_id])); ?>" type="button" class="btn btn-success btn-sm"><?php echo e(__('general.buy')); ?></a> <a href="<?php echo e(route('remove-from-favorite',['locale'=>$locale, 'id'=>$row->product_id])); ?>" type="button" class="btn btn-danger btn-sm">Remove Favorite</a></td>
			                                   
			                                </tr>
			                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			                                
			                                
			                            </tbody>
			                        </table>
			                    </div>
			                </div>
			            </div>
						<?php else: ?>

				        <div style="padding-top: 50px;" class="row">
				            <div style="text-align: center;" class="col-sm-6 col-md-6 col-md-offset-3 col-sm-offset-3">
				                <h2><?php echo e(__('general.no-favorite-product')); ?>!</h2>
				            </div>
				        </div>

				     <?php endif; ?>
					</div>
					<!-- Content -->
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.profile-tab', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>