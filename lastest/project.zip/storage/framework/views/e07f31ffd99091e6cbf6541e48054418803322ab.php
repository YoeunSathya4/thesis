<?php $__env->startSection('title', 'KHEMARAKSMEY'); ?>
<?php $__env->startSection('home', 'active'); ?>

<?php $__env->startSection('appbottomjs'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <!--BANNER-->
        <div id="main-slider" class="main-slider">

            <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
                <img src="<?php echo e(asset ('public/uploads/slide/image/'.$slide->image)); ?>" alt="">
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <!--BANNER-->
        <?php echo $__env->make('frontend.layouts.sidebar.product_search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <section class="book-collection">
            <div class="container">
                <div class="row">
                        <div class="col-xs-12">
                           <div class="collection">

                                <!-- Secondary heading -->
                                <div class="sec-heading">
                                    <h3><?php echo e(__('general.product-category')); ?></h3>
                                </div>
                                <!-- Secondary heading -->

                                <div class="row">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                  <div class="col-lg-3">
                                    <a href="<?php echo e(route('product', $locale)); ?>?category=<?php echo e($category->id); ?>" class="thumbnail">
                                        <img class="rounded-circle" style="width: 100%;" src="<?php echo e(asset('public/uploads/category/image/'.$category->image)); ?>" alt="Generic placeholder image" width="140" height="140">
                                    </a>
                                    <a href="#">
                                        <h3 style="text-align: center;"> <?php echo e($category->name); ?> </h3>
                                    </a>
                                  </div><!-- /.col-lg-4 -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                        </div>
                    <!-- Book Collections Tabs -->

                </div>
            </div>
        </section>

        <!-- Best Seller Products -->
<!-- Book Collections -->
        <section class="book-collection">
            <div class="container">
                <div class="row">
                        <div class="col-xs-12">
                           <div class="collection">

                                <!-- Secondary heading -->
                                <div class="sec-heading">
                                    <h3><?php echo e(__('general.feature-product')); ?></h3>
                                </div>
                                <!-- Secondary heading -->

                                <!-- Collection Content -->
                                    <?php $__currentLoopData = $products->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div style="padding-bottom: 30px;" class="row">
                                        <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-4">
                                            <div class="s-product">
                                                <div class="s-product-img">
                                                    <img class="product-css" src="<?php echo e(asset ('public/uploads/product/image/'.$product->image)); ?>" alt="">
                                                    <div class="s-product-hover">
                                                        <div class="position-center-x">
                                                            
                                                            
                                                            <a class="btn-1 sm shadow-0" data-toggle="modal" href="<?php echo e(route('product-detail',['locale'=>$locale, 'slug'=>$product->slug])); ?>"><?php echo e(__('general.quick-view')); ?></a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <h6 style="text-align: center;"><a href="<?php echo e(route('product-detail',['locale'=>$locale, 'slug'=>$product->slug])); ?>"><?php echo e($product->name); ?></a></h6>
                                                <h4 style="text-align: center;" ><b >Price:</b> $<?php echo e($product->unit_price); ?></h4>
                                                <div class="col-xs-12">
                                                    <div class="col-xs-6">
                                                        <a class="btn-1 sm shadow-0" data-toggle="modal" href="<?php echo e(route('add-to-cart',['locale'=>$locale, 'id'=>$product->id])); ?>"><span class="fa fa-shopping-cart"></span> <?php echo e(__('general.add-to-cart')); ?></a>
                                                    </div>
                                                    <div class="col-xs-6">
                                                       
                                                       

                                                        <?php if($product->favorites()->first() == null): ?>
                                                           <?php ($favorite = 0); ?> 
                                                        <?php else: ?>
                                                            <?php ($favorite = 1); ?>
                                                        <?php endif; ?>
                                                        <?php if(Auth::guard('customer')->user()): ?>
                                                        <?php if($favorite == 1): ?>
                                                        <a href="<?php echo e(route('remove-from-favorite',['locale'=>$locale, 'id'=>$product->id])); ?>" class="btn-1 sm shadow-0 blank"><i class="fa fa-heart"></i> <?php echo e(__('general.favorite')); ?> </a>
                                                        <?php else: ?>
                                                            <a style="background: #b09b9b;" href="<?php echo e(route('add-to-favorite',['locale'=>$locale, 'id'=>$product->id])); ?>" class="btn-1 sm shadow-0"><i class="fa fa-heart"></i> <?php echo e(__('general.favorite')); ?> </a>
                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                            <a style="background: #b09b9b;" href="<?php echo e(route('add-to-favorite',['locale'=>$locale, 'id'=>$product->id])); ?>" class="btn-1 sm shadow-0"><i class="fa fa-heart"></i> <?php echo e(__('general.favorite')); ?> </a>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                <!-- Collection Content -->
                                

                            </div>

                        </div>
                        <div style="padding-top: 20px;" class="col-lg-12">
                                    <div class="col-lg-4">
                                    </div>
                                    
                                    <div style="    padding-left: 96px;" class="col-lg-4">
                                        <a href="<?php echo e(route('product',$locale)); ?>" class="btn-1 sm shadow-0"> <?php echo e(__('general.view-more')); ?> <i aria-hidden="true" class="fa fa-arrow-circle-right"></i></a>
                                    </div>
                                    <div class="col-lg-4">
                                    </div>
                                </div>
                    <!-- Book Collections Tabs -->

                </div>
            </div>
        </section>
        <!-- Book Collections --> 


    
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>