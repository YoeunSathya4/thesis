<?php $__env->startSection('section-title', 'Size'); ?>
<?php $__env->startSection('tab-active-sub-category', 'active'); ?>
<?php $__env->startSection('about-active-main-category', 'active'); ?>


<?php $__env->startSection('imageuploadjs'); ?>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tab-js'); ?>
	<script type="text/javascript">
		function showIsDelete(id){
			active = 0;
			$.ajax({
			        url: "<?php echo e(route('cp.category.sub-category.update-main-category-delete-status')); ?>",
			        method: 'POST',
			        data: {id:id, active:active },
			        success: function( response ) {
			            if ( response.status === 'success' ) {
			            	swal("Nice!", response.msg ,"success");
			            	location.reload();
			            }else{
			            	swal("Error!", "Sorry there is an error happens. " ,"error");
			            }
			        },
			        error: function( response ) {
			           swal("Error!", "Sorry there is an error happens. " ,"error");
			        }
				});
		}
	</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('about'); ?>
	<br />
	<div>
		<div class="col-md-12">
			<a style="float: right;margin-bottom: 10px;margin-top: -10px;" href="<?php echo e(route('cp.category.sub-category.create-mainCategory',['id'=>$id, 'subcategory_id'=>$subcategory_id])); ?>"  class="tabledit-delete-button btn btn-sm btn-primary" style="float: none;"><span class="fa fa-plus"></span></a>
		</div>
	</div><!--.row-->
	<?php if(count($data)>0): ?>
	<div class="table-responsive">
		<table id="table-edit" class="table table-bordered table-hover">
			<thead>
				<tr>
					<th>#</th>
					<th>Name in Khmer</th>
					<th>Name in English</th>
					<?php if(Auth::user()->position_id == 1): ?>
						<th>Created By</th>
						<th>Created By</th>
						<th>Updated By</th>
						<?php endif; ?>
					<th>Updated Date</th>
					<?php if(Auth::user()->position_id == 1): ?>
					<th>Delete By</th>
					<th>Delete Date</th>
					<?php endif; ?>
					<th></th>
				</tr>
			</thead>
			<tbody>

				<?php ($i = 1); ?>
				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($i++); ?></td>
						<td><?php echo e($row->kh_name); ?></td>
						<td><?php echo e($row->en_name); ?> </td>
						<?php if(Auth::user()->position_id == 1): ?>
							<td><?php if($row->updater != ''): ?> <?php echo e($row->creator->name); ?>  <?php else: ?> no Creator <?php endif; ?></td>
							<td><?php echo e($row->created_at); ?></td>
							<td><?php if($row->updater != ''): ?> <?php echo e($row->updater->name); ?> <?php else: ?> no updater <?php endif; ?></td>
							<?php endif; ?>
						<td><?php echo e($row->updated_at); ?></td>
						<?php if(Auth::user()->position_id == 1): ?>
							<td><?php if($row->deleter != ''): ?> <?php echo e($row->deleter->name); ?> <?php else: ?> no deleter <?php endif; ?></td>
							<td><?php echo e($row->deleted_at); ?></td>
						<?php endif; ?>
						<td style="white-space: nowrap; width: 1%;">
							<div class="tabledit-toolbar btn-toolbar" style="text-align: left;">
	                           	<div class="btn-group btn-group-sm" style="float: none;">
	                           		<a href="<?php echo e(route('cp.category.sub-category.edit-mainCategory', ['category_id'=>$id,'subcategory_id'=>$subcategory_id,'maincategory_id'=>$row->id])); ?>" class="tabledit-edit-button btn btn-sm btn-success" style="float: none;"><span class="fa fa-eye"></span></a>
	                           		

	                           		<?php if(Auth::user()->position_id == 1): ?>
	                           			<a href="#" onclick="deleteConfirm('<?php echo e(route('cp.category.sub-category.delete-mainCategory', $row->id)); ?>', '<?php echo e(route('cp.category.sub-category.mainCategory',['category_id'=>$id,'subcategory_id'=>$subcategory_id])); ?>')" class="tabledit-delete-button btn btn-sm btn-danger" style="float: none;"><span class="glyphicon glyphicon-trash"></span></a>
	                           		<?php else: ?>
		                           		<a href="#" onclick="deleteConfirm('<?php echo e(route('cp.category.sub-category.trash-mainCategory', $row->id)); ?>', '<?php echo e(route('cp.category.sub-category.mainCategory',['category_id'=>$id,'subcategory_id'=>$subcategory_id])); ?>')" class="tabledit-delete-button btn btn-sm btn-danger" style="float: none;"><span class="glyphicon glyphicon-trash"></span></a>
		                           		<?php endif; ?>
		                           		<?php if(Auth::user()->position_id == 1): ?>
		                           			<?php if($row->is_deleted == 1): ?>
 											<button onclick="showIsDelete(<?php echo e($row->id); ?>)" class="tabledit-edit-button btn btn-sm btn-warning" style="float: none;"> <span class="fa fa-check"></span> Restore</button>
 											<?php endif; ?>
		                           		<?php endif; ?>
	                           	</div>
	                       </div>
	                    </td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div >
	<?php else: ?>
	No Data
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cp.category.sub-category.tabForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>