<?php $__env->startSection('title', 'KHEMARAKSMEY | Checkout'); ?>
<?php $__env->startSection('register', 'active'); ?>

<?php $__env->startSection('appbottomjs'); ?>
<script src="https://js.stripe.com/v2/"></script>
<script src="<?php echo e(asset('public/frontend/js/checkout.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
<div style="padding-top: 20px;padding-bottom: 100px;" class="container">
    <div class=" panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title"><strong><?php echo e(__('general.thank')); ?></strong></h3><br>
        </div>
        <div class="panel-body">
           <div class="alert alert-success" role="alert">
                <?php echo e(__('general.well-done')); ?> <a style="font-size: 23px;
    color: #ee383a;" href="<?php echo e(route('order-history',$locale)); ?>"> <b> <?php echo e(__('general.click-to-see-invoice')); ?> </b></a>
            </div>
        </div>
    </div>
</div>
    <?php if(!Auth::guard('customer')->user()): ?>
        <script type="text/JavaScript">
        window.location.replace('<?php echo e(route('login',$locale)); ?>');
        </script>
    <?php endif; ?>

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>