<?php $__env->startSection('title', 'KHEMARAKSMEY | Checkout'); ?>
<?php $__env->startSection('register', 'active'); ?>

<?php $__env->startSection('appbottomjs'); ?>
<script src="https://js.stripe.com/v2/"></script>
<script src="<?php echo e(asset('public/frontend/js/checkout.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
<div style="padding-top: 20px" class="container">
    <div class=" panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title"><strong><?php echo e(__('general.favorite-product')); ?></strong></h3><br>
            <h4><?php echo e(__('general.your-total')); ?>: $ <?php echo e($total); ?></h4>
        </div>
        <div class="panel-body">
            <div id="charge-error" class="alert alert-danger" <?php echo e(!Session::has('error') ? 'hidden' : ''); ?>>
                <?php echo e(Session::get('error')); ?>

            </div>
            <form action="<?php echo e(route('checkouts',$locale)); ?>" method="post" id="checkout-form">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('POST')); ?>


                <!-- <div class="form-group row">
                    <label class="col-sm-2 form-control-label" for="en_name"><?php echo e(__('general.name')); ?></label>
                    <div class="col-sm-10">
                        <input  id="name"
                                name="name"
                                value = ""
                                type="text"
                                placeholder = "<?php echo e(__('general.ex')); ?>. <?php echo e(__('general.sovan')); ?>"
                                class="form-control">
                    </div>
                </div> -->
                <!-- <div class="form-group row">
                    <label class="col-sm-2 form-control-label" for="address"><?php echo e(__('general.address')); ?></label>
                    <div class="col-sm-10">
                        <input  id="address"
                                name="address"
                                value = ""
                                type="text"
                                placeholder = "<?php echo e(__('general.ex')); ?>. #7A,street 428 Sangkat Boeng Trabeak, Khan Chamkamorn, Phnom Penh"
                                class="form-control">
                    </div>
                </div> -->

                <div class="form-group row">
                    <label class="col-sm-2 form-control-label" for="card-name"><?php echo e(__('general.card-holder-name')); ?></label>
                    <div class="col-sm-10">
                        <input  id="card-name"
                                name="card-name"
                                value = ""
                                type="text"
                                placeholder = "Enter your Card name"
                                class="form-control">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 form-control-label" for="card-number"><?php echo e(__('general.credit-card-number')); ?></label>
                    <div class="col-sm-10">
                        <input  id="card-number"
                                name="card-number"
                                value = ""
                                type="text"
                                placeholder = "ex: 42424242424242"
                                class="form-control">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 form-control-label" for="card-expiry-month"><?php echo e(__('general.expiration-month')); ?></label>
                    <div class="col-sm-10">
                        <input  id="card-expiry-month"
                                name="card-expiry-month"
                                value = ""
                                type="text"
                                placeholder = "ex: 04"
                                class="form-control">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 form-control-label" for="card-expiry-year"><?php echo e(__('general.expiration-year')); ?></label>
                    <div class="col-sm-10">
                        <input  id="card-expiry-year"
                                name="card-expiry-year"
                                value = ""
                                type="text"
                                placeholder = "ex: 22"
                                class="form-control">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 form-control-label" for="card-cvc">CVC</label>
                    <div class="col-sm-10">
                        <input  id="card-cvc"
                                name="card-cvc"
                                value = ""
                                type="text"
                                placeholder = "ex: 123"
                                class="form-control">
                    </div>
                </div>
                <button style="float: right;" type="submit" class="btn btn-success"><?php echo e(__('general.buy-now')); ?></button>
            </form>
        </div>
    </div>
</div>
    <?php if(!Auth::guard('customer')->user()): ?>
        <script type="text/JavaScript">
        window.location.replace('<?php echo e(route('login',$locale)); ?>');
        </script>
    <?php endif; ?>

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>