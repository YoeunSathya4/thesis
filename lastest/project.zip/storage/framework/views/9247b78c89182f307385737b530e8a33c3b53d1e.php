<?php $__env->startSection('section-title', 'Size'); ?>
<?php $__env->startSection('tab-active-sub-category', 'active'); ?>
<?php $__env->startSection('about-active-main-category', 'active'); ?>
<?php $__env->startSection('tab-css'); ?>
	<style type="text/css">
		.margin-top-10{
			margin-top:10px;
		}
		
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tab-js'); ?>
	<script type="text/JavaScript">
		$(document).ready(function(event){
		
			$('#form').validate({
				modules : 'file',
				submit: {
					settings: {
						inputContainer: '.form-group',
						errorListClass: 'form-tooltip-error'
					}
				}
			}); 
			
		}); 
	</script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('about'); ?>
	<?php echo $__env->make('cp.layouts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php ($en_name = ""); ?>
		<?php ($kh_name = ""); ?>
       
       	<?php if(Session::has('invalidData')): ?>
            <?php ($invalidData = Session::get('invalidData')); ?>
            <?php ($en_name = $invalidData['en_name']); ?>
            <?php ($kh_name = $invalidData['kh_name']); ?>
            
       	<?php endif; ?>

   	
	<form id="form" action="<?php echo e(route('cp.category.sub-category.store-mainCategory')); ?>" name="form" method="POST"  enctype="multipart/form-data">
		<?php echo e(csrf_field()); ?>

		<?php echo e(method_field('PUT')); ?>

		<input type="hidden" name="category_id" value="<?php echo e($id); ?>">
		<input type="hidden" name="subcategory_id" value="<?php echo e($subcategory_id); ?>">
		
		<div class="form-group row">
					<label class="col-sm-2 form-control-label" for="en_name">Name (ENG)</label>
					<div class="col-sm-10">
						<input 	id="en_name"
								name="en_name"
							   	value = "<?php echo e($en_name); ?>"
							   	type="text"
							   	placeholder = "Please enter name in English"
							   	class="form-control"
							   	data-validation="[L>=1, L<=200]"
								 />
								
					</div>
			</div>
			<div class="form-group row">
					<label class="col-sm-2 form-control-label" for="kh_name">Name (KHM)</label>
					<div class="col-sm-10">
						<input 	id="kh_name"
								name="kh_name"
							   	value = "<?php echo e($kh_name); ?>"
							   	type="text"
							   	placeholder = "Please enter name in Khmer"
							   	class="form-control"
							   	data-validation="[L>=1, L<=200]"
								 />
								
					</div>
			</div>
		<div class="form-group row">
			<label class="col-sm-2 form-control-label"></label>
			<div class="col-sm-10">
				<button type="submit" class="btn btn-success"> <fa class="fa fa-plus"></i> Create</button>	
			</div>
		</div>
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cp.category.sub-category.tabForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>