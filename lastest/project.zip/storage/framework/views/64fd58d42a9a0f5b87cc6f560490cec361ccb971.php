<?php $__env->startSection('title', 'ABOUT US| KHEMARAKSMEY'); ?>
<?php $__env->startSection('about-us', 'active'); ?>

<?php $__env->startSection('appbottomjs'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- breadcrumb -->
    <div class="parallax-window inner-banner tc-padding overlay-dark" data-parallax="scroll" data-image-src="<?php echo e(asset('public/frontend/images/banner.jpg')); ?>">
        <div class="container">
            <div class="inner-page-heading h-white style-2">
                <h2><?php echo e(__('general.about-us')); ?></h2>
            </div>
        </div>
    </div>
<!-- Breadcrumb -->

        <!-- Service And Mission -->
        <section class="service-nd-mission tc-padding-top white-bg">
            <div  class="container">
                

                <!-- Mission & values -->
                <div class="mission tc-padding-bottom">
                    <div class="row">

                        <!-- Mission Disc -->
                        <div class="col-lg-12 col-xs-12">
                            <div class="mission-disc">
                                <h4><?php echo e(__('general.company-profile')); ?></h4><hr>
                                <strong><?php if($aboutUsContent != ''): ?> <?php echo $aboutUsContent->content; ?> <?php else: ?> No Data Here!  <?php endif; ?></strong>
                                
                            </div>
                        </div>
                        <!-- Mission Disc -->

                    </div>
                </div>
                <!-- Mission & values -->

            </div>
        </section>
        <!-- Service And Mission -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>