<select id="maincategory_id" name="maincategory_id" class="form-control">
	
	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>			
		<option value="<?php echo e($row->id); ?>"><?php echo e($row->en_name); ?> (<?php echo e($row->kh_name); ?>)</option>	
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
</select>