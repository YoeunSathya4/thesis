<?php $__env->startSection('tab-active-about', 'active'); ?>

<?php $__env->startSection('tab-content'); ?>
	
	<section class="box-typical files-manager">
		<nav class="files-manager-side" style="height: auto;">
			<ul class="files-manager-side-list">
				<li><a href="<?php echo e(route('cp.category.sub-category.edit', ['id'=>$id, 'subcategory_id'=>$subcategory_id])); ?>" class="<?php echo $__env->yieldContent('about-active-overview'); ?>">Overview</a></li>
				<li><a href="<?php echo e(route('cp.category.sub-category.mainCategory', ['id'=>$id, 'subcategory_id'=>$subcategory_id])); ?>" class="<?php echo $__env->yieldContent('about-active-main-category'); ?>"> Main Category</a></li>
				
			</ul>
		</nav><!--.files-manager-side-->

		<div class="files-manager-panel">
			<div class="files-manager-panel-in">
				<div class="container-fluid">
					<?php echo $__env->yieldContent('about'); ?>
				</div>
			</div><!--.files-manager-panel-in-->
		</div><!--.files-manager-panels-->
	</section>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cp.category.tab', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>