<?php $__env->startSection('title', 'NEWS | KHEMARAKSMEY'); ?>
<?php $__env->startSection('news', 'active'); ?>

<?php $__env->startSection('appbottomjs'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <div class="parallax-window inner-banner tc-padding overlay-dark" data-parallax="scroll" data-image-src="<?php echo e(asset('public/frontend/images/banner.jpg')); ?>">
        <div class="container">
            <div class="inner-page-heading h-white style-2">
                <h2><?php echo e(__('general.news')); ?></h2>            
            </div>
        </div>
    </div>
<!-- Breadcrumb -->
        <!-- Blog List -->
        <div class="tc-padding">
            <div class="container">
                <div class="row">
                    
                    <!-- Content -->
                    <div class="col-lg-9 col-md-8 col-xs-12">

                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- List Blog -->
                        <div class="blog-list">
                            <div class="list-blog">
                                <div class="row">
                                    <div class="col-lg-4 col-md-12">
                                        <img src="<?php echo e(asset ('public/uploads/news/image/'.$row->image)); ?>" alt="">
                                    </div>
                                    <div class="col-lg-8 col-md-12">
                                        <div class="blog-detail">
                                            <h3><?php echo e($row->title); ?></h3>
                                            
                                            <p><?php echo e($row->description); ?></p>
                                            <a href="<?php echo e(route('news-detail',['locale'=>$locale, 'slug'=>$row->slug])); ?>" class="btn-1 shadow-0 sm"><?php echo e(__('general.learn-more')); ?><i class="fa fa-arrow-circle-right"></i></a> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                        <!-- List Blog -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($data->links('vendor.pagination.frontend-html')); ?>

                    </div>
                    <!-- Content -->

                    <!-- Aside -->
                    <aside class="col-lg-3 col-md-4 col-xs-12">

                        <!-- Aside Widget -->
                        <div class="aside-widget">
                            <h6><?php echo e(__('general.promotion')); ?></h6>
                            <ul class="books-year-list">
                                <?php ($promotions = $defaultData['promotions']); ?>
                                <?php $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li id="list-promotion">
                                        <div class="books-post-widget">
                                            <img src="<?php echo e(asset ('public/uploads/promotion/image/'.$promotion->image)); ?>" id="image-show" alt="">
                                            <h6><a href="#"><?php echo e($promotion->title); ?></a></h6>
                                            
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <!-- Aside Widget -->


                </div>
            </div>
        </div>
        <!-- Blog List -->

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>