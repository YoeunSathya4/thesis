<?php $__env->startSection('headercss'); ?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <link rel="stylesheet" href="<?php echo e(asset ('public/cp/css/lib/font-awesome/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset ('public/cp/css/lib/bootstrap-sweetalert/sweetalert.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset ('public/cp/css/main.css')); ?>">
    <script type="text/javascript" src="<?php echo e(asset ('public/cp/js/lib/jquery/jquery.min.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset ('public/cp/css/lib/summernote/summernote.css')); ?>"/>
    <?php echo $__env->yieldContent('appheadercss'); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('bodyclass'); ?>
    class="with-side-menu control-panel control-panel-compact"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>

<header class="site-header">
    <div class="container-fluid">
        <a target="_blank" href="<?php echo e(url('/')); ?>" class="site-logo">
            <img class="hidden-md-down" style="height: 60px;" src="<?php echo e(asset ('public/cp/img/logo.png')); ?>" alt="">
            <img class="hidden-lg-up" src="<?php echo e(asset ('public/cp/img/logo.png')); ?>" alt="">
        </a>
        <button class="hamburger hamburger--htla">
            <span>toggle menu</span>
        </button>
        <div class="site-header-content">
            <div class="site-header-content-in">
                <div class="site-header-shown">
                    
                    <div class="dropdown user-menu">
                        <button class="dropdown-toggle" id="dd-user-menu" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img src="<?php echo e(asset ('public/uploads/user/image/'.Auth::user()->avatar)); ?>" alt="">
                        </button>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dd-user-menu">
                            <a class="dropdown-item" href="<?php echo e(route('cp.profile.profile.edit')); ?>"><span class="fa fa-user"></span> Profile</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?php echo e(route('cp.auth.logout')); ?>"><span class="fa fa-sign-out"></span> Logout</a>
                        </div>
                    </div>

                    <button type="button" class="burger-right">
                        <i class="font-icon-menu-addl"></i>
                    </button>
                </div><!--.site-header-shown-->

                <div class="mobile-menu-right-overlay"></div>
                
            </div><!--site-header-content-in-->
        </div><!--.site-header-content-->
    </div><!--.container-fluid-->
</header><!--.site-header-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    <?php ($menu = ""); ?>
    <?php if(isset($_GET['menu'])): ?>
        <?php ( $menu = $_GET['menu']); ?>
    <?php endif; ?>
    

    <div class="mobile-menu-left-overlay"></div>
    <nav class="side-menu">
        <ul class="side-menu-list"> 
           <?php if(Auth::user()->position_id == 1): ?>
            <li class="red <?php echo $__env->yieldContent('active-main-menu-dashboard'); ?>">
                <a href="<?php echo e(route('cp.dashboard.index')); ?>">
                <span>
                    <i class="fa fa-desktop"></i>
                    <span class="lbl">Dashboard</span>
                </span>
                </a>
            </li>
             <li class="<?php echo $__env->yieldContent('active-main-menu-order'); ?> red with-sub">
                <span>
                    <i class=" font-icon fa fa-bell"></i>
                    <span class="lbl"> Orders</span>
                </span>
                <ul>
                    <!-- <li class=""><a href="<?php echo e(route('cp.order.new-order')); ?>"><span class="lbl">New Orders</span></a></li>
                    <li class=""><a href="<?php echo e(route('cp.order.order-form')); ?>"><span class="lbl">Order Form</span></a></li> -->
                    <li class=""><a href="<?php echo e(route('cp.order.all-order')); ?>"><span class="lbl">All Orders</span></a></li>
                </ul>
            </li>
            <li class="red <?php echo $__env->yieldContent('active-main-menu-customer'); ?>">
                <a href="<?php echo e(route('cp.customer.customer.index')); ?>">
                <span>
                    <i class="fa fa-address-book"></i>
                    <span class="lbl">Customers</span>
                </span>
                </a>
            </li>
            <?php endif; ?>
            <li class="red <?php echo $__env->yieldContent('active-main-menu-slide'); ?>">
                <a href="<?php echo e(route('cp.slide.index')); ?>">
                <span>
                    <i class="fa fa-desktop"></i>
                    <span class="lbl">Slide</span>
                </span>
                </a>
            </li>
            <li class="red <?php echo $__env->yieldContent('active-main-menu-news'); ?>">
                <a href="<?php echo e(route('cp.news.index')); ?>">
                <span>
                    <i class="fa fa-book"></i>
                    <span class="lbl">News</span>
                </span>
                </a>
            </li>
            <li class="red <?php echo $__env->yieldContent('active-main-menu-home'); ?>">
                <a href="<?php echo e(route('cp.content.content.edit', ['slug' => 'about-us'])); ?>?menu=AboutUs">
                <span>
                    <i class="fa fa-user"></i>
                    <span class="lbl">Company Profile</span>
                </span>
                </a>
            </li>
           

            <li class="<?php echo $__env->yieldContent('active-main-menu-medai'); ?> red with-sub">
                <span>
                    <i class=" font-icon fa fa-globe"></i>
                    <span class="lbl"> Medai</span>
                </span>
                <ul>
                    <!-- <li class=""><a href="<?php echo e(route('cp.announcement.index')); ?>"><span class="lbl">Announment</span></a></li> -->
                    <li class=""><a href="<?php echo e(route('cp.promotion.index')); ?>"><span class="lbl">Promotion</span></a></li>
                </ul>
            </li>

            <li class="<?php echo $__env->yieldContent('active-main-menu-product'); ?> red with-sub">
                <span>
                    <i class=" font-icon fa fa-book"></i>
                    <span class="lbl"> Product</span>
                </span>
                <ul>
                    <li class=""><a href="<?php echo e(route('cp.product.index')); ?>"><span class="lbl">Product</span></a></li>
                    <li class=""><a href="<?php echo e(route('cp.category.index')); ?>"><span class="lbl">Category</span></a></li>
                </ul>
            </li>
            
        
            <?php if(Auth::user()->position_id == 1): ?>
            <li class="red <?php echo $__env->yieldContent('active-main-menu-user'); ?>">
                <a href="<?php echo e(route('cp.user.user.index')); ?>">
                <span>
                    <i class="fa fa-users"></i>
                    <span class="lbl">User</span>
                </span>
                </a>
            </li>
            <?php endif; ?>
           
        </ul>
    </nav><!--.side-menu-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        
        <?php echo $__env->yieldContent('page-content'); ?>
        
    </div>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('bottomjs'); ?>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
        <?php echo $__env->yieldContent('imageuploadjs'); ?>
        <script type="text/javascript" src="<?php echo e(asset ('public/cp/js/lib/tether/tether.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset ('public/cp/js/lib/bootstrap/bootstrap.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset ('public/cp/js/plugins.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset ('public/cp/js/lib/lobipanel/lobipanel.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset ('public/cp/js/lib/match-height/jquery.matchHeight.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset ('public/cp/js/lib/bootstrap-sweetalert/sweetalert.min.js')); ?>"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
        <script src="<?php echo e(asset ('public/cp/js/lib/bootstrap-select/bootstrap-select.min.js')); ?>"></script>
        <script src="<?php echo e(asset ('public/cp/js/lib/select2/select2.full.min.js')); ?>"></script>
       <script src="<?php echo e(asset ('public/cp/js/lib/summernote/summernote.min.js')); ?>"></script>
       

       <script>
            $(document).ready(function() {
                $('.summernote').summernote();
            });
        </script>

        <script src="<?php echo e(asset ('public/cp/js/app.js')); ?>"></script>
        <script src="<?php echo e(asset ('public/cp/js/camcyber.js')); ?>"></script>
        <?php echo $__env->yieldContent('appbottomjs'); ?>

        <?php if(Session::has('msg')): ?>
        <script type="text/JavaScript">
            toastr.success("<?php echo Session::get('msg'); ?>");
        </script>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
        <script type="text/JavaScript">
            toastr.error("<?php echo Session::get('error'); ?>");
        </script>
        <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cp.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>