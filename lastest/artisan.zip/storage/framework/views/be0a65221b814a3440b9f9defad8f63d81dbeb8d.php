<?php $__env->startSection('title', 'NEWS | KHEMARAKSMEY'); ?>
<?php $__env->startSection('product', 'active'); ?>

<?php $__env->startSection('appbottomjs'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <div class="parallax-window inner-banner tc-padding overlay-dark" data-parallax="scroll" data-image-src="<?php echo e(asset('public/frontend/images/banner.jpg')); ?>">
        <div class="container">
            <div class="inner-page-heading h-white style-2">
                <h2><?php echo e(__('general.product-detail')); ?></h2>            
            </div>
        </div>
    </div>

    <!-- Book Detail -->
        <div style="padding-top: 20px;" class="book-detail">
            <div class="container">
                
                <!-- Alert -->
                <!-- <div class="add-cart-alert">
                    <p><i class="fa fa-check-circle"></i>The Complete Book of Vegetables </p>
                    <a class="btn-1 sm pull-right shadow-0" href="#">view cart</a>
                </div> -->
                <!-- Alert -->

                <!-- Single Book Detail -->
                <div class="single-boook-detail">
                    <div class="row">
                        
                        <!-- Book Thumnbnail -->
                        <div class="col-lg-4 col-md-5">
                            <div class="product-thumnbnail">

                                <img src="<?php echo e(asset ('public/uploads/product/image/'.$data->image)); ?>">
                            </div>
                        </div>
                        <!-- Book Thumnbnail -->

                        <!-- book Detail -->
                        <div class="col-lg-8 col-md-7">
                            <div class="single-product-detail">
                                <h3><?php echo e($data->name); ?></h3>
                                <span style="color: black;" class="availability"><?php echo e(__('general.availability')); ?> :<strong><?php echo e($data->product_qty); ?> <?php echo e(__('general.stock')); ?><i class="fa fa-check-circle"></i></strong></span>

                                <span style="color: black;" class="availability"><?php echo e(__('general.price')); ?> :<strong><?php echo e($data->unit_price); ?><i class="fa fa-dollar"></i></strong></span>

                                
                                
                                <h4><?php echo e(__('general.description')); ?></h4>
                                <p><?php echo $data->description; ?></p>
                                <!-- <div class="quantity-box">
                                    <label>Qty :</label>
                                    <form id='myform' method='POST' action='http://techlinqs.com/html/bookstore-0.2/bookstore-ltr/123'>
                                        <input type='button' value='-' class='qtyminus'/>
                                        <input type='number' name='quantity' value='1' class='qty' />
                                        <input type='button' value='+' class='qtyplus'/>
                                    </form>
                                </div> -->
                                <ul class="btn-list">
                                    <li style="margin-right: 10px;"><a class="btn-1 sm shadow-0 " href="<?php echo e(route('add-to-cart',['locale'=>$locale, 'id'=>$data->id])); ?>"><?php echo e(__('general.add-to-cart')); ?></a></li>
                                    <?php if($data->favorites()->first() == null): ?>
                                       <?php ($favorite = 0); ?> 
                                    <?php else: ?>
                                        <?php ($favorite = 1); ?>
                                    <?php endif; ?>
                                    <?php if($favorite == 1): ?>
                                    <li><a href="<?php echo e(route('remove-from-favorite',['locale'=>$locale, 'id'=>$data->id])); ?>" class="btn-1 sm shadow-0 blank"><i class="fa fa-heart"></i> </a></li>
                                    <?php else: ?>
                                        <a style="background: #b09b9b;" href="<?php echo e(route('add-to-favorite',['locale'=>$locale, 'id'=>$data->id])); ?>" class="btn-1 sm shadow-0"><i class="fa fa-heart"></i>  </a>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                        <!-- book Detail -->
                        

                    </div>

                </div>
                <!-- Single Book Detail -->
                <!-- Related Products -->
                <div class="related-products">
                    <h3 style="padding-top: 10px"><?php echo e(__('general.related-product')); ?></h3>
                    <div style="padding-top: 10px" class="related-produst-slider">
                        <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('product-detail',['locale'=>$locale, 'slug'=>$product->slug])); ?>">
                            <div class="item">
                                <div class="product-box">
                                    <div class="product-img">
                                        <img src="<?php echo e(asset ('public/uploads/product/image/'.$product->image)); ?>" alt="">
                                        
                                    </div>
                                    <div class="product-detail">
                                        <h5><?php echo e($product->name); ?></h5>
                                        <div class="rating-nd-price">
                                            <strong>$ <?php echo e($product->unit_price); ?></strong>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <!-- Related Products -->
            </div>
        </div>
        <!-- Book Detail --> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>