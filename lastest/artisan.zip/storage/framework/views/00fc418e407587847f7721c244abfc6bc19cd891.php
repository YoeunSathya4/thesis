<?php if(sizeof($data) > 0): ?>
		<div class="table-responsive">
			<table id="table-edit" class="table table-bordered table-hover">
				<thead>
					<tr>
						<th>Product Name</th>
						<th>Price</th>
						<th>QTY</th>
						<th></th>
					</tr>
				</thead>
				<tbody>

					<?php ($i = 1); ?>
					<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td>
								<input type="hidden" name="product_id" id="product-id-<?php echo e($row->id); ?>" value="<?php echo e($row->id); ?>">
								<input type="hidden" name="name" id="name-<?php echo e($row->id); ?>" value="<?php echo e($row->en_name); ?>">
							
								<b><?php echo e($row->en_name); ?></b>
							</td>
							<td>
								<input type="hidden" name="price" id="price-<?php echo e($row->id); ?>" value="<?php echo e($row->unit_price); ?>">
								<?php echo e($row->unit_price); ?>

							</td>
							<td>
								<input  type="number" min=1 class="form-control" id="qty-<?php echo e($row->id); ?>" placeholder="" value="1"> <br />
								<textarea class="form-control" id="instruction-<?php echo e($row->id); ?>" placeholder="Instruction"></textarea>
							</td>
							
							<td style="white-space: nowrap; width: 1%;">
								<div class="tabledit-toolbar btn-toolbar" style="text-align: left;">
		                           	<div class="btn-group btn-group-sm" style="float: none;">
		                           		<button class="tabledit-edit-button btn btn-sm btn-success" onclick="add(<?php echo e($row->id); ?>)" style="float: none;"><span class="fa fa-check"></span></button>
		                           	</div>
		                       </div>
		                    </td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div >
	<?php else: ?>
		<span>No Data</span>
	<?php endif; ?>