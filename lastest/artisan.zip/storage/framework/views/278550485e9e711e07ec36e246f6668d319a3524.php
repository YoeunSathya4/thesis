<?php $__env->startSection('title', 'KHEMARAKSMEY | Porfile'); ?>
<?php $__env->startSection('my-profile', 'profile-active'); ?>


<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset ('public/cp/css/plugin/fileinput/fileinput.min.css')); ?>" media="all" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset ('public/cp/css/plugin/fileinput/theme.css')); ?>" media="all" rel="stylesheet" type="text/css"/>
    <!-- some CSS styling changes and overrides -->
    <style>
        .kv-avatar .file-preview-frame,.kv-avatar .file-preview-frame:hover {
            margin: 0;
            padding: 0;
            border: none;
            box-shadow: none;
            text-align: center;
        }
        .kv-avatar .file-input {
            display: table-cell;
            max-width: 220px;
        }
        #profileMenu{
        	color: #ffffff;font-size: 18px;text-align: center;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('appbottomjs'); ?>
<script type="text/javascript" src="<?php echo e(asset ('public/cp/js/plugin/fileinput/fileinput.min.js')); ?>" type="text/javascript"></script>
    <script type="text/javascript" src="<?php echo e(asset ('public/cp/js/plugin/fileinput/theme.js')); ?>" type="text/javascript"></script>
    <script>
        
        var btnCust = ''; 
        $("#image").fileinput({
            overwriteInitial: true,
            maxFileSize: 1500,
            showClose: false,
            showCaption: false,
            showBrowse: false,
            browseOnZoneClick: true,
            removeLabel: '',
            removeIcon: '<i class="glyphicon glyphicon-remove"></i>',
            removeTitle: 'Cancel or reset changes',
            elErrorContainer: '#kv-avatar-errors-2',
            msgErrorClass: 'alert alert-block alert-danger',
            defaultPreviewContent: '<img src="<?php if($data->image != ''): ?> <?php echo e(asset('public/uploads/customers/image/'.$data->image)); ?> <?php else: ?> http://via.placeholder.com/200x165 <?php endif; ?>" alt="Missing Image" class="img img-responsive"><span class="text-muted">Click to select <br /><i style="font-size:12px">Image dimesion must be .jpg or .png type</i></span>',
            layoutTemplates: {main2: '{preview} ' +  btnCust + ' {remove} {browse}'},
            allowedFileExtensions: ["jpg", "png", "gif"]
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('profile'); ?>
     <!-- Content -->
					<div class="col-lg-9 col-md-8 col-xs-12 pull-right pull-none">
						<h1 style="padding-left: 50%;"> <?php echo e(__('general.my-profile')); ?></h1><br/>
						<?php if(count($errors) > 0): ?>
						    
						    <div style="max-width: 322px; margin: 0 auto">
                                        <div class="alert alert-danger alert-no-border alert-close alert-dismissible fade in" role="alert">
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">×</span>
                                            </button>
                                            <ul>
									            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									                <li><?php echo e($error); ?></li>
									            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									        </ul>
                                        </div>  
                                    </div>
						<?php endif; ?>
						<form style="padding-left: 40px;" id="form" action="<?php echo e(route('update-profile')); ?>" name="form" method="POST"  enctype="multipart/form-data">
					        <?php echo e(csrf_field()); ?>

					        <?php echo e(method_field('POST')); ?>

					        <input type="hidden" name="id" value="<?php echo e($data->id); ?>">

					        <div class="form-group row">
					            <label class="col-sm-2 form-control-label" for="en_name"><?php echo e(__('general.name')); ?></label>
					            <div class="col-sm-10">
					                <input  id="name"
					                        name="name"
					                        value = "<?php echo e($data->name); ?>"
					                        type="text"
					                        placeholder = "<?php echo e(__('general.ex')); ?>. <?php echo e(__('general.sovan')); ?>"
					                        class="form-control">
					            </div>
					        </div>
					        
					        <div class="form-group row">
					            <label class="col-sm-2 form-control-label" for="email"><?php echo e(__('general.email')); ?></label>
					            <div class="col-sm-10">
					                <input  id="email"
					                        name="email"
					                        value = "<?php echo e($data->email); ?>"
					                        type="text"
					                        placeholder = "<?php echo e(__('general.ex')); ?>. you@example.com"
					                        class="form-control"
					                        data-validation="[EMAIL]">
					            </div>
					        </div>
					        
					        <div class="form-group row">
					            <label class="col-sm-2 form-control-label" for="phone"><?php echo e(__('general.phone')); ?></label>
					            <div class="col-sm-10">
					                <input  id="phone"
					                        name="phone"
					                        value = "<?php echo e($data->phone); ?>"
					                        type="text" 
					                        placeholder = "<?php echo e(__('general.ex')); ?>. 093123457"
					                        class="form-control"
					                        data-validation="[L>=9, L<=10, numeric]"
					                        data-validation-message="$ is not correct." 
					                        data-validation-regex="/(^[00-9].{8}$)|(^[00-9].{9}$)/"
					                        data-validation-regex-message="$ must start with 0 and has 10 or 11 digits" />
					                        
					            </div>
					        </div>
					        <div class="form-group row">
					            <label class="col-sm-2 form-control-label" for="location"><?php echo e(__('general.location')); ?></label>
					            <div class="col-sm-10">
					                <input  id="location"
					                        name="location"
					                        value = "<?php echo e($data->location); ?>"
					                        type="text"
					                        placeholder = "<?php echo e(__('general.ex')); ?>. <?php echo e(__('general.chom-chav')); ?>"
					                        class="form-control">
					            </div>
					        </div>
					        <div class="form-group row">
					            <label class="col-sm-2 form-control-label" for="address"><?php echo e(__('general.address')); ?></label>
					            <div class="col-sm-10">
					                <input  id="address"
					                        name="address"
					                        value = "<?php echo e($data->address); ?>"
					                        type="text"
					                        placeholder = "<?php echo e(__('general.ex')); ?>. #7A,street 428 Sangkat Boeng Trabeak, Khan Chamkamorn, Phnom Penh"
					                        class="form-control">
					            </div>
					        </div>
					        <div class="form-group row">
					            <label class="col-sm-2 form-control-label" for="email"><?php echo e(__('general.image')); ?></label>
					            <div class="col-sm-10">
					                <div class="kv-avatar center-block">
					                    <input id="image" name="image" type="file" class="file-loading">
					                </div>
					            </div>
					        </div>
					    
					    
					        <div class="form-group row">
					            <label class="col-sm-2 form-control-label"></label>
					            <div class="col-sm-10">
					                <button type="submit" class="btn btn-success"> <fa class="fa fa-cog"></i> <?php echo e(__('general.update')); ?></button>
					                
					            </div>
					        </div>
					    </form>
					    <h1 style="padding-left: 50%;"> <?php echo e(__('general.change-password')); ?></h1><br/>
					    <?php if(count($errors) > 0): ?>
						    
						    <div style="max-width: 322px; margin: 0 auto">
                                        <div class="alert alert-danger alert-no-border alert-close alert-dismissible fade in" role="alert">
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">×</span>
                                            </button>
                                            <ul>
									            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									                <li><?php echo e($error); ?></li>
									            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									        </ul>
                                        </div>  
                                    </div>
						<?php endif; ?>
					    <form style="padding-left: 40px;" id="form" action="<?php echo e(route('change-password')); ?>" name="form" method="POST"  enctype="multipart/form-data">
					        <?php echo e(csrf_field()); ?>

					        <?php echo e(method_field('POST')); ?>

					        <input type="hidden" name="id" value="<?php echo e($data->id); ?>">

					        <div class="form-group row">
					            <label class="col-sm-2 form-control-label" for="en_name"><?php echo e(__('general.current-password')); ?></label>
					            <div class="col-sm-10">
					                <input  id="old_password"
					                        name="old_password"
					                        value = ""
					                        type="password"
					                        placeholder = ""
					                        class="form-control">
					            </div>
					        </div>
					    	<div class="form-group row">
					            <label class="col-sm-2 form-control-label" for="en_name"><?php echo e(__('general.new-password')); ?></label>
					            <div class="col-sm-10">
					                <input  id="new_password"
					                        name="new_password"
					                        value = ""
					                        type="password"
					                        placeholder = ""
					                        class="form-control">
					            </div>
					        </div>
					        <div class="form-group row">
					            <label class="col-sm-2 form-control-label" for="en_name"><?php echo e(__('general.confirm-password')); ?></label>
					            <div class="col-sm-10">
					                <input  id="confirm_password"
					                        name="confirm_password"
					                        value = ""
					                        type="password"
					                        placeholder = ""
					                        class="form-control">
					            </div>
					        </div>
					        <div class="form-group row">
					            <label class="col-sm-2 form-control-label"></label>
					            <div class="col-sm-10">
					                <button type="submit" class="btn btn-primary"> <fa class="fa fa-cog"></i> <?php echo e(__('general.change')); ?> </button>
					                
					            </div>
					        </div>
					    </form>
					</div>
					<!-- Content -->
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.profile-tab', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>