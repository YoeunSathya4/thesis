<?php $__env->startSection('title', 'KHEMARAKSMEY | Order History Detail'); ?>
<?php $__env->startSection('order-history', 'profile-active'); ?>


<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset ('public/cp/css/plugin/fileinput/fileinput.min.css')); ?>" media="all" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset ('public/cp/css/plugin/fileinput/theme.css')); ?>" media="all" rel="stylesheet" type="text/css"/>
    <!-- some CSS styling changes and overrides -->
    <style>
        .kv-avatar .file-preview-frame,.kv-avatar .file-preview-frame:hover {
            margin: 0;
            padding: 0;
            border: none;
            box-shadow: none;
            text-align: center;
        }
        .kv-avatar .file-input {
            display: table-cell;
            max-width: 220px;
        }
        #profileMenu{
        	color: #ffffff;font-size: 18px;text-align: center;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('appbottomjs'); ?>
<script type="text/javascript" src="<?php echo e(asset ('public/cp/js/plugin/fileinput/fileinput.min.js')); ?>" type="text/javascript"></script>
    <script type="text/javascript" src="<?php echo e(asset ('public/cp/js/plugin/fileinput/theme.js')); ?>" type="text/javascript"></script>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('profile'); ?>
     <!-- Content -->
					<div class="col-lg-9 col-md-8 col-xs-12 pull-right pull-none">
						<?php if($details): ?>
						<div class="panel panel-default">
			                <div class="panel-heading">
			                    <h3 class="panel-title"><strong><?php echo e(__('general.invoice')); ?></strong></h3>
			                </div>
			                <div class="panel-body">
			                    <div class="table-responsive">
			                        <table class="table table-condensed">
			                            <thead>
			                                <tr>
			                                    <td><strong><?php echo e(__('general.product')); ?></strong></td>
			                                    <td class="text-center"><strong><?php echo e(__('general.price')); ?></strong></td>
			                                    <td class="text-center"><strong><?php echo e(__('general.quantity')); ?></strong></td>
			                                    <td class="text-right"> <?php echo e(__('general.total')); ?> ($)</td>
			                                    
			                                </tr>
			                            </thead>
			                            <tbody>
			                            	<?php ($total_amount = 0); ?>
											<?php ($sumExtra = 0); ?>
											<?php ($total = 0); ?>
			                                <!-- foreach ($order->lineItems as $line) or some such thing here -->
			                                <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                                <?php ($total_amount += $row->unit_price * $row->qty); ?>
			                                <tr>
			                                    <td><?php echo e($row->product->productName); ?> </td>
			                                    <td class="text-center"><?php echo e($row->unit_price); ?></td>
			                                    <td class="text-center"><?php echo e($row->qty); ?></td>
			                                    <td class="text-right"> <?php echo e($row->unit_price * $row->qty); ?></td>
			                                    
			                                </tr>
			                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                                 <tr>
			                                    <td class="no-line"></td>
			                                    <td class="no-line"></td>
			                                    <td class="no-line text-center"><strong><?php echo e(__('general.grand-total')); ?></strong></td>
			                                    <td class="no-line text-right"><?php echo e($total_amount); ?> $</td>
			                                </tr>
			                               
			                                <tr>
			                                    <td class="no-line"></td>
			                                    <td class="no-line"></td>
			                                    <td class="no-line text-center"><strong></strong></td>
			                                    <td class="no-line text-right"><a href="<?php echo e(route('order-history',['locale'=>$locale])); ?>" type="button" class="btn btn-primary btn-sm"> <i class="fa fa-arrow-left"></i> <?php echo e(__('general.back')); ?></a></td>
			                                </tr>
			                                
			                                
			                            </tbody>
			                        </table>
			                    </div>
			                </div>
			            </div>
						<?php else: ?>

				        <div style="padding-top: 50px;" class="row">
				            <div style="text-align: center;" class="col-sm-6 col-md-6 col-md-offset-3 col-sm-offset-3">
				                <h2><?php echo e(__('general.no-history-order')); ?>!</h2>
				            </div>
				        </div>

				     <?php endif; ?>
					</div>
					<!-- Content -->
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.profile-tab', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>