<?php if(sizeof($carts) > 0): ?>
	
		<div class="table-responsive">
			<table id="table-edit" class="table table-bordered table-hover">
				<thead>
					<tr>
						<th>Product</th>
						<th>Instruction</th>
						<th>Price</th>
						<th>QTY</th>
						<th></th>
					</tr>
				</thead>
				<tbody>
					<?php ($total_amount = 0); ?>
					<?php ($sumExtra = 0); ?>
					<?php ($i = 1); ?>
					<?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						
						<?php ($total_amount += $row['price'] * $row['qty']); ?>

						<tr>
							<td>
								<input type="hidden" name="name" id="name" value="">
								<b><?php echo e($row['name']); ?></b>
							</td>
							
							<td><?php echo e($row['instruction']); ?></td>
							<td><?php echo e($row['price']); ?> $</td>
							<td><?php echo e($row['qty']); ?></td>
							
						
							<td><a href="#" class="tabledit-edit-button btn btn-sm btn-danger" onclick="removeItem(<?php echo e($row['id']); ?>)" style="float: none;"><span class="fa fa-times"></span></a></td>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	

						<tr>
							<td colspan="4" style="text-align: right;">Total in USD</td>
							<td>$ <?php echo e($total_amount + $sumExtra); ?></td>
						</tr>
						<tr>
							<td colspan="4" style="text-align: right;">Discount ( % )</td>
							<td><input 	id="discount" name="discount" value = "0" type="text" placeholder = "Enter Discount" class="form-control"></td>
						</tr>
				</tbody>
			</table>
			
			
		</div >
	<?php else: ?>
		<span>No Data</span>
	<?php endif; ?>