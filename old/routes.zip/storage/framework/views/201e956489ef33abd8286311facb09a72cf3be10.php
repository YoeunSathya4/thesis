<?php $__env->startSection('section-title', 'Properties'); ?>
<?php $__env->startSection('tab-active-property', 'active'); ?>

<?php $__env->startSection('section-js'); ?>
<script type="text/javascript">	
	$(document).ready(function(event){

		$("#btn-add").click(function(){
    		add();
    	})
	});

	<?php if(checkPermision($route.'.add-property')): ?>
	function add(){
		
			swal({
				title: "Property",
				text: "Please type a listing code:",
				type: "input",
				showCancelButton: true,
				closeOnConfirm: false,
				inputPlaceholder: "Write something"
			}, function (inputValue) {
				if (inputValue === false) return false;
				if (inputValue === "") {
					swal.showInputError("You need to write a listing code!");
					return false
				}
				
				//swal("Nice!", "You wrote: " + inputValue, "success");
				$.ajax({
			        url: "<?php echo e(route($route.'.properties-add', $id)); ?>?owner_id=<?php echo e($id); ?>",
			        method: 'POST',
			        data: { listing_code:inputValue},
			        success: function( response ) {
			            if ( response.status === 'success' ) {
			            	swal("Nice!", response.msg ,"success");
			            	location.reload();
			            }else if( response.status === 'erorr' ){
			            	swal("Sorry!", response.msg );
			            }else{
			            	swal("Error!", "Sorry there is an error happens. " ,"error");
			            }
			        },
			        error: function( response ) {
			           swal("Error!", "Sorry there is an error happens. " ,"error");
			        }
				});

			});
	}
	<?php endif; ?>

	

</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tab-content'); ?>
	<div>
		<div class="col-md-12">
			<?php if(checkPermision($route.'.add-property')): ?><a style="float: right;margin-bottom: 10px;margin-top: -10px;" id="btn-add" class="tabledit-delete-button btn btn-sm btn-primary" style="float: none;"><span class="fa fa-plus"></span></a><?php endif; ?>	
		</div>
	</div><!--.row-->
	<?php if(sizeof($data) > 0): ?>
	<div class="table-responsive">
		<table id="table-edit" class="table table-bordered table-hover">
			<thead>
				<tr>
					<th>#</th>
					<th width=15%>Staff In Charge</th>
					<th>Listing Code</th>
					<th>Action</th>
					<th>Last Update</th>
					<th></th>
				</tr>
			</thead>
			<tbody>

				<?php ($i = 1); ?>
				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($i++); ?></td>
						<td class="table-photo"  >
							<?php ($charge = staffInCharge($row) ); ?>
							<?php if(!empty($charge)): ?>
								<img src="<?php echo e(asset ($charge->staff->picture)); ?>" alt="" data-toggle="tooltip" data-placement="bottom" title="<?php echo e($charge->staff->en_name); ?>" style="display:inline"> <b><?php echo e($charge->staff->en_name); ?></b>
							<?php endif; ?>
						</td>
						<td><?php echo e(makeListingCode($row)); ?></td>
						<td><?php echo e($row->action->en_name); ?></td>
						<td><?php echo e($row->updated_at); ?></td>
						<td style="white-space: nowrap; width: 1%;">
							<div class="tabledit-toolbar btn-toolbar" style="text-align: left;">
	                           	<div class="btn-group btn-group-sm" style="float: none;">
	                           		<?php if(checkIfHasRole($row->id)): ?>
	                           		<a href="<?php echo e(route('user.property.check-role', $row->id)); ?>" class="tabledit-edit-button btn btn-sm btn-success" style="float: none;"><span class="fa fa-eye"></span></a>
	                           		<?php endif; ?>
	                           		<?php if(checkPermision($route.'.remove-property')): ?><button onclick="deleteConfirm('<?php echo e(route($route.'.properties-remove', $row->id)); ?>', '<?php echo e(route($route.'.properties', $id)); ?>')" class="tabledit-edit-button btn btn-sm btn-danger" style="float: none;"><span class="fa fa-trash"></span></button><?php endif; ?>
	                           	</div>
	                       </div>
	                    </td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div >
	<?php else: ?>
		<span>No Data</span>
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($route.'.tab', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>