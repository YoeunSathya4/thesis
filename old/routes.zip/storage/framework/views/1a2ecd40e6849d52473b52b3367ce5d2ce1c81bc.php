<?php $__env->startSection('title', 'Order'); ?>
<?php $__env->startSection('active-manu-order', 'active'); ?>

<?php $__env->startSection('tab-css'); ?>
    <link href="<?php echo e(asset ('public/cp/css/plugin/fileinput/fileinput.min.css')); ?>" media="all" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset ('public/cp/css/plugin/fileinput/theme.css')); ?>" media="all" rel="stylesheet" type="text/css"/>
    <!-- some CSS styling changes and overrides -->
    <style>
        .kv-avatar .file-preview-frame,.kv-avatar .file-preview-frame:hover {
            margin: 0;
            padding: 0;
            border: none;
            box-shadow: none;
            text-align: center;
        }
        .kv-avatar .file-input {
            display: table-cell;
            max-width: 220px;
        }
    </style>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-js'); ?>
	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<h1 class="page-header">Order</h1>
<div class="container"> 
    <div style="    padding-right: 19px;padding-bottom: 10px;" class="row">
        
    </div> 
    <div class="table-responsive">
        <table id="table-edit" class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Success</th>
                    <th>Location</th>
                    <th>Address</th>
                    <th>Delevery Time</th>
                    <th>Discount</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>

                <?php ($i = 1); ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        
                        <td><?php echo e($row->location->name); ?></td>
                        <td><?php echo e($row->address); ?></td>
                        <td><?php echo e($row->delivery_time); ?></td>
                        <td><?php echo e($row->discount); ?></td>
                        <td><a href="#" onclick="orderDetail(<?php echo e($row->id); ?>)" class="tabledit-edit-button btn btn-sm btn-success" data-toggle="modal" data-target="#orderDetail" style="float: none;"><span class="fa fa-eye"></span></a></td>
                    </tr>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
            </tbody>
        </table>

    </div >                    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>