<?php $__env->startSection('newsletter-js'); ?>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
    <script>
    $(document).ready(function() {
      $("#newsletter-form").submit(function(event){
        event.preventDefault();
        email = $("#form-email").val();

        //alert(phone);
            if(email != ""){
                if(validateEmail(email)){
                    
                    $.ajax({
                      url: "<?php echo e(route('submit-newsletter', ['locale'=>$locale])); ?>",
                      type: 'PUT',
                      data: {email:email},
                      success: function( response ) {
                         email = $("#form-email").val('');
                         toastr.success("<?php echo e(__('general.contact-successful-sent')); ?>");
                         //email = $("#email_newsleter").val('');
                      },
                      error: function( response ) {
                         toastr.warning("<?php echo e(__('general.sorry')); ?>");
                      }
                      
                  });
                    }else{
                        error(event, "email", '<?php echo e(__('general.incorrectemail')); ?>');
                            $('#form-email').focus();
                    }
                }else{
                    error(event, "email", '<?php echo e(__('general.erroremail')); ?>.');
                    $('#form-email').focus();
                }
            
        })

    });
    
    function validateEmail(email) { 
        var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    }
    function validatePhone(phone) {
        return phone.match(/(^[00-9].{8}$)|(^[00-9].{9}$)/);
    }
    function error(event, obj, msg){
      event.preventDefault();
      toastr.error(msg);
      $("#"+obj).focus();
    }
   
  </script>
<?php $__env->stopSection(); ?>


<section class="module cta newsletter">
    <div class="container">
    <div class="row">
      <div class="col-lg-7 col-md-7">
        <h3><?php echo e(__('general.sign-up-for-our-newsletter')); ?></h3>
        <p><?php echo e(__('general.latest-properties')); ?></p>
      </div>
      <div class="col-lg-5 col-md-5">
        <form method="post" id="newsletter-form" class="newsletter-form">
          
          <input type="email" id="form-email" name="email" placeholder="<?php echo e(__('general.your-email')); ?>" />
          <button type="submit" form="newsletter-form"><i class="fa fa-send"></i></button>
        </form>
      </div>
    </div><!-- end row -->
    </div><!-- end container -->
  </section>