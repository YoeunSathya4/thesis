<?php $__env->startSection('section-title', 'Overview'); ?>
<?php $__env->startSection('tab-active-edit', 'active'); ?>
<?php $__env->startSection('tab-css'); ?>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('imageuploadjs'); ?>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tab-js'); ?>
	<script type="text/JavaScript">
		$(document).ready(function(event){
		
			// $('#form').validate({
			// 	modules : 'file',
			// 	submit: {
			// 		settings: {
			// 			inputContainer: '.form-group',
			// 			errorListClass: 'form-tooltip-error'
			// 		}
			// 	}
			// }); 
			
		}); 
		
	</script>

	

	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tab-content'); ?>
	<?php echo $__env->make('user.layouts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<form id="form" action="<?php echo e(route($route.'.update')); ?>" name="form" method="POST"  enctype="multipart/form-data">
		<?php echo e(csrf_field()); ?>

		<?php echo e(method_field('POST')); ?>

		<input type="hidden" name="id" value="<?php echo e($data->id); ?>">
		
		<div class="form-group row">
			<label class="col-sm-2 form-control-label" for="name">Name</label>
			<div class="col-sm-10">
				<input 	id="name"
						name="name"
					   	value = "<?php echo e($data->name); ?>"
					   	type="text"
					   	placeholder = "Eg. Jhon Son"
					   	class="form-control" />
						
			</div>
		</div>

		<div class="form-group row">
			<label class="col-sm-2 form-control-label" for="phone">Phone 1</label>
			<div class="col-sm-10">
				<input 	id="phone1"
						name="phone1"
					   	value = "<?php echo e($data->phone1); ?>"
					   	type="text" 
					   	placeholder = "Eg. 093123457"
					   	class="form-control"
					   	data-validation="[L>=9, L<=10, numeric]"
						data-validation-message="$ is not correct." 
						data-validation-regex="/(^[00-9].{8}$)|(^[00-9].{9}$)/"
						data-validation-regex-message="$ must start with 0 and has 9 or 10 digits" />
						
			</div>
		</div>
		<div class="form-group row">
			<label class="col-sm-2 form-control-label" for="phone">Phone 2</label>
			<div class="col-sm-10">
				<input 	id="phone2"
						name="phone2"
					   	value = "<?php echo e($data->phone2); ?>"
					   	type="text" 
					   	placeholder = "Eg. 093123457"
					   	class="form-control" />
						
			</div>
		</div>
		
		<div class="form-group row">
			<label class="col-sm-2 form-control-label" for="email">E-mail</label>
			<div class="col-sm-10">
				<input 	id="email"
						name="email"
						value = "<?php echo e($data->email); ?>"
						type="text"
						placeholder = "Eg. you@example.com"
					   	class="form-control" >
			</div>
		</div>

		<div class="form-group row">
			<label class="col-sm-2 form-control-label" for="email">Address</label>
			<div class="col-sm-10">
				<input 	id="address"
						name="address"
						value = "<?php echo e($data->address); ?>"
						type="text"
					   	class="form-control">
			</div>
		</div>

		
		
		<div class="form-group row">
			<label class="col-sm-2 form-control-label"></label>
			<div class="col-sm-10">
				<?php if(checkPermision($route.'.update')): ?><button type="submit" class="btn btn-success"> <fa class="fa fa-cog"></i> Update</button><?php endif; ?>
				<?php if(checkPermision($route.'.trash')): ?><button type="button" onclick="deleteConfirm('<?php echo e(route($route.'.trash', $data->id)); ?>', '<?php echo e(route($route.'.index')); ?>')" class="btn btn-danger"> <fa class="fa fa-trash"></i> Delete</button><?php endif; ?>
			</div>
		</div>
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($route.'.tab', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>