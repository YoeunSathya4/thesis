<?php if(sizeof($carts) > 0): ?>
	
		<div class="table-responsive">
			<table id="table-edit" class="table table-bordered table-hover">
				<thead>
					<tr>
						<th>Res. & Menu</th>
						<th>Size</th>
						<th>Instruction</th>
						<th>Price</th>
						<th>QTY</th>
						<th>Extra</th>
						<th>Price</th>
						<th></th>
					</tr>
				</thead>
				<tbody>
					<?php ($total_amount = 0); ?>
					<?php ($sumExtra = 0); ?>
					<?php ($i = 1); ?>
					<?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						
						<?php ($total_amount += $row['size'] * $row['qty']); ?>

						<tr>
							<td>
								<input type="hidden" name="name" id="name" value="">
								<b><?php echo e($row['name']); ?></b>
							</td>
							<td>
								<input type="hidden" name="name" id="name" value="">
								<b><?php echo e($row['sizeName']); ?></b>
							</td>
							<td><?php echo e($row['instruction']); ?></td>
							<td><?php echo e($row['size']); ?> $</td>
							<td><?php echo e($row['qty']); ?></td>
							<td>
								<?php ($extras = json_decode($row['extras'])); ?>
								
								<?php $__currentLoopData = $extras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li><?php echo e($extra->name); ?> : <?php echo e($extra->price); ?> $</li>
									<?php ($sumExtra += $extra->price); ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
								
							</td>
							<td>
								<?php if(sizeof($row['extras']) > 0): ?>
								

								<?php echo e($row['size'] * $row['qty'] + $sumExtra); ?> $

								<?php else: ?>
									<?php echo e($row['size'] * $row['qty']); ?> $
								<?php endif; ?>
							</td>
							<td><a href="#" class="tabledit-edit-button btn btn-sm btn-danger" onclick="removeItem(<?php echo e($row['id']); ?>)" style="float: none;"><span class="fa fa-times"></span></a></td>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	

						<tr>
							<td colspan="5" style="text-align: right;">Total in USD</td>
							<td>$ <?php echo e($total_amount + $sumExtra); ?></td>
						</tr>
						<tr>
							<td colspan="5" style="text-align: right;">Discount ( % )</td>
							<td><input 	id="discount" name="discount" value = "0" type="text" placeholder = "Enter Discount" class="form-control"></td>
						</tr>
				</tbody>
			</table>
			
			
		</div >
	<?php else: ?>
		<span>No Data</span>
	<?php endif; ?>