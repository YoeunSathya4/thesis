<?php $__env->startSection('property-js'); ?>
<script type="text/javascript"> 


  $(document).ready(function(){
      //$('#amount').val('');
      $( function() {
          $( "#slider-range" ).slider({
            range: true,
            min:0,
            max:10000,
            values: [0,10000 ],
            slide: function( event, ui ) {
              $( "#amount" ).val( "" + ui.values[0]+"-"+ui.values[1]);
              $( "#minPrice" ).val(ui.values[0]);
              $( "#maxPrice" ).val(ui.values[1]);
            }
          });

          $( "#amount" ).val( "" + $( "#slider-range" ).slider( "values", 0 ) +
            "-" + $( "#slider-range" ).slider( "values", 1 ) );
          $( "#minPrice" ).val($( "#slider-range" ).slider( "values", 0 ));
          $( "#maxPrice" ).val($( "#slider-range" ).slider( "values", 1 ));
        } );

      
    
    $("#frm-search").submit(function(e){
      e.preventDefault();
      search();
    })
    $("#limit").change(function(){
      search();
    })
    $("#province").change(function(){
      getDistricts($(this).val());
    })
    $('#district').change(function(){
        getCommunes($(this).val());
      })

  })

  function search(){
    action    = $('#action').val();
    type    = $('#type').val();
    province  = $('#province').val();
    district   = $('#district').val();
    commune   = $('#commune').val();
    listing_code    = $('#listing_code').val();
    min     = $('#minPrice').val();
    max     = $('#maxPrice').val();

    limit     = 9;

    url="?limit="+limit;
    if(action != 0){
      url += '&action='+action;
    }

    if(province != 0){
      url += '&province='+province;
      if(district != 0){
        url += '&district='+district;
        if(commune != 0){
          url += '&commune='+commune;
        }
      }
    }
    if(type != 0){
      url += '&type='+type;
    }

    if(listing_code != ""){
      url += '&listing_code='+listing_code;
    }
   
    if(min != ""){
      url += '&min='+min;
    }
    if(max != ""){
      url += '&max='+max;
    }
    
    
    $(location).attr('href', '<?php echo e(route('search-property',$locale)); ?>'+url);
  }

  //=============================================>> Location
  function getDistricts(province_id){
      //Empty the district
      $("#district").html('<option value="0" >District</option>');
      //Empty the communes
      $("#commune").html('<option value="0" >Commune</option>');
      
      //Get Districts
      if(province_id != 0){
        $.ajax({
                url: "<?php echo e(route('user.property.districts')); ?>?province_id="+province_id,
                type: 'GET',
                data: {},
                success: function( response ) {
                   var districts = '';
                    var i;
                var length = response.length;
                for (i = 0; i < length; i++) {
                    districts += '<option value="'+response[i].id+'" >'+response[i].name+'</option>';
                }
                if(districts != ""){
                  $('#district').append(districts);
                  
                }
                
                },
                error: function( response ) {
                   swal("Error!", "Sorry there is an error happens. " ,"error");
                }
              
        });
      }
  }
  function getCommunes(district_id){
    //Empty the communes
    $("#commune").html('<option value="0" >Commune</option>');

    if(district_id != 0){
      $.ajax({
              url: "<?php echo e(route('user.property.communes')); ?>?district_id="+district_id,
              type: 'GET',
              data: {},
              success: function( response ) {
                 var communes = '';
                  var i;
              var length = response.length;
              for (i = 0; i < length; i++) {
                  communes += '<option value="'+response[i].id+'" >'+response[i].name+'</option>';
              }
              if(communes != ""){
                $('#commune').append(communes);
              }
              
              },
              error: function( response ) {
                 swal("Error!", "Sorry there is an error happens. " ,"error");
              }
            
      });
    }
  }

  
  
</script>
<?php $__env->stopSection(); ?>

<div class="findhome-listing-filterable">
  <form class="findhome-listing-select" id="frm-search">
      <ul>
          <li class="col-sm-3">
             <label><?php echo e(__('general.property-code')); ?>:</label> 
              <input style="background: white;" type="text" id="listing_code" name="listing_code" placeholder="<?php echo e(__('general.property-code')); ?>">
          </li>
          <li class="col-sm-3">
              <label><?php echo e(__('general.status')); ?>:</label>
              <div class="findhome-banner-select">
                  <select name="action" id="action">
                     <option value="0"><?php echo e(__('general.status')); ?></option>
                      <?php ($actions = $defaultData['actions']); ?>
                      <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($row->id); ?>" ><?php echo e($row->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
              </div>
          </li>
          <li class="col-sm-3">
              <label><?php echo e(__('general.type')); ?>:</label>
              <div class="findhome-banner-select">
                  <select name="type" id="type">
                     <option value="0"><?php echo e(__('general.type')); ?></option>
                      <?php ($types = $defaultData['types']); ?>
                      <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($row->id); ?>" ><?php echo e($row->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
              </div>
          </li>
          <li style="width: 223px;" class="col-sm-3">
              <label><?php echo e(__('general.price-range')); ?>:</label>
              <div class="price_filter">
                                    <div id="slider-range"></div>
                                    <div class="price_slider_amount">
                                        <input type="text" id="amount" name="price" placeholder="<?php echo e(__('web.add-your-price')); ?>" />
                                        <input type="hidden" name="min" id="minPrice" />
                                        <input type="hidden" name="max" id="maxPrice" />
                                    </div>
                                </div>
          </li>
          <li class="col-sm-3">
              <label><?php echo e(__('general.province')); ?>:</label>
              <div class="findhome-banner-select">
                  <select name="province" id="province">
                     <option value="0"><?php echo e(__('general.province')); ?></option>
                      <?php ($provinces = $defaultData['provinces']); ?>
                      <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($row->id); ?>" ><?php echo e($row->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
              </div>
          </li>
          <li class="col-sm-3">
              <label><?php echo e(__('general.district')); ?>:</label>
              <div class="findhome-banner-select" id="district-cnt">
                  <select name="district" id="district">
                     <option value="0"><?php echo e(__('general.district')); ?></option>
                  </select>
              </div>
          </li>
          <li class="col-sm-3">
              <label><?php echo e(__('general.commune')); ?>:</label>
              <div class="findhome-banner-select" id="commune-cnt">
                  <select name="commune" id="commune">
                     <option value="0"><?php echo e(__('general.commune')); ?></option>
                  </select>
              </div>
          </li>
          <li class="col-sm-3"><label class="banner-submit"><input type="submit" value="<?php echo e(__('general.search')); ?>" class="findhome-bgcolor"></label></li>
      </ul>
  </form>
 
</div>