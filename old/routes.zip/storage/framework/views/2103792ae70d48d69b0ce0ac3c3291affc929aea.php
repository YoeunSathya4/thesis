<?php $__env->startSection('title', 'Y.A.O Realty'); ?>
<?php $__env->startSection('home', 'active'); ?>

<?php $__env->startSection('appbottomjs'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  
    <style type="text/css">
        .col-md-4{
            height: 429px;
        }
    </style>
	<!--// Main Banner \\-->
		<div class="findhome-banner">
            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                  <!-- Indicators -->
                  <ol class="carousel-indicators">
                    <?php ($i=0); ?>
                    <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <li data-target="#carousel-example-generic" data-slide-to="<?php echo e($i); ?>" class="<?php if($i == 0): ?> active  <?php endif; ?> <?php ($i++); ?>"></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                  </ol>
                  <!-- Wrapper for slides -->
                  <div class="carousel-inner" role="listbox">
                    <?php ($i=0); ?>
                    <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item <?php if($i == 0): ?> active  <?php endif; ?> <?php ($i++); ?>">
                      <img src="<?php echo e(asset ($row->image)); ?>" alt="">
                      <div class="carousel-caption">
                      </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>

                  <!-- Controls -->
                  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
                    <span class="fa fa-chevron-left" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                  </a>
                  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
                    <span class="fa fa-chevron-right" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                  </a>
                </div>
           
            

        </div>
		<!--// Main Banner \\-->
        <div class="findhome-main-content">
          <div class="container">
            
            <div class="findhome-fancy-title">
                <h2 class="findhome-color"><?php echo e(__('web.browse-our-most-popular-categories')); ?></h2>
                <div class="findhome-fancy-shape"><span><small></small></span></div>
            </div>

           <div class="row quick-links-container quick-links-container-padding "> 
                    <?php $__currentLoopData = $property_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="quick-links-box col-xs-6 col-lg-2 text-center">
                      <a href="<?php echo e(route('search-property', ['locale'=>$locale])); ?>?limit=9&type=<?php echo e($row->id); ?>">
                        <img data-src="<?php echo e(asset($row->icon)); ?>" alt="">
                        <h3><?php echo e($row->name); ?></h3>
                      </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
      </div><!-- end container -->
    </div>
		<!--// Main Content \\-->
		<div class="findhome-main-content">

			<!--// Main Section \\-->
			<div class="findhome-main-section">
				<div class="container">
					<div class="row">
						
						<div class="col-md-12">
                            <div class="findhome-fancy-title">
                                <h2 class="findhome-color"><?php echo e(__('web.top-listing')); ?></h2>
                                <div class="findhome-fancy-shape"><span><small></small></span></div>
                            </div>

                            <?php echo $__env->make('frontend.layouts.sidebar.property-search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <div class="tab-content">
                                <div role="tabpanel" class="tab-pane fade in active" id="grid">
                                    <div class="findhome-listing findhome-listing-classic">
                                        <ul class="row">
                                            <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="col-md-4">
                                                <figure> 
                                                    <?php if($row->action_id == 1 ): ?>
                                                        <span><?php echo e(__('web.for-sale')); ?></span>
                                                    <?php elseif( $row->action_id == 2 ): ?>
                                                        <span class="color-two"><?php echo e(__('web.for-rent')); ?></span>
                                                    <?php else: ?>
                                                        <span class="color-two"><?php echo e(__('web.rent-sale')); ?></span>
                                                    <?php endif; ?>
                                                    <a href="<?php echo e(route('property-detail',['locale'=>$locale,'slug'=>$row->slug])); ?>"><img src="<?php echo e(asset($row->media->feature)); ?>" alt=""><span class="img-transparent"></span></a>
                                                    <figcaption>
                                                        <ul class="findhome-listing-option">
                                                            <?php ($details = $row->propertyDetails()->where(array('is_showed'=>1))->limit(3)->get()); ?>
                                                            <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php ($name = $line->detail()->select($locale.'_name as name')->first() ); ?>

                                                                <li> <?php if(!empty($line->detail->icon)): ?> <img width="20px" data-src="<?php echo e(asset($line->detail->icon)); ?>" alt=""> <?php endif; ?> <?php echo e($line->value); ?> <?php if(!empty($line->detail->unit)): ?> <?php echo e($line->detail->unit); ?> <?php endif; ?></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <!-- <li><a href="listing-detail.html"><i class="icon-furniture"></i> 02</a></li>
                                                            <li><a href="listing-detail.html"><i class="fa fa-area-chart"></i> 250 sq ft</a></li> -->
                                                        </ul>
                                                    </figcaption>
                                                </figure>
                                                <div class="findhome-listing-classic-text">
                                                   <h6><a href="<?php echo e(route('property-detail',['locale'=>$locale,'slug'=>$row->slug])); ?>"><?php echo e($row->name); ?></a></h6>
                                                   <?php if(!empty($row->location->address)): ?><span><i class="fa fa-map-marker"></i> <?php echo e($row->location->address); ?></span><?php endif; ?>
                                                   
                                                   <!-- <p>Lorem ipsum dolor sit amet, consectetur adips elit. Nunc congue diam sit amet sem tristque utrum sem ornare. </p> -->
                                                </div>
                                                <div class="findhome-user-post">
                                                    <h6><?php if($row->action_id == 1 ): ?>
                                                            <?php echo e(displayMoney($row->price->selling_price)); ?> 
                                                        <?php elseif( $row->action_id == 2 ): ?>
                                                            <?php echo e(displayMoney($row->price->rental_price)); ?> 
                                                        <?php else: ?>
                                                            Sell: <?php echo e(displayMoney($row->price->selling_price)); ?> <br />
                                                            Rent: <?php echo e(displayMoney($row->price->rental_price)); ?> 
                                                        <?php endif; ?></h6>
                                                        <?php ($now = Carbon\Carbon::now()); ?>
                                                    <time datetime="2008-02-14 20:00"><i class="fa fa-calendar-o"></i> <?php echo e(Carbon\Carbon::parse($row->created_at)->diffForHumans($now)); ?></time>
                                                </div>
                                            </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </ul>
                                        <a href="<?php echo e(route('property',['locale'=>$locale])); ?>" class="findhome-readmore-btn findhome-bgcolor"><?php echo e(__('web.view-more-property')); ?></a>
                                    </div>
                                </div>
                            </div>
                        </div>

					</div>
				</div>
			</div>
			<!--// Main Section \\-->
		</div>
		<!--// Main Content \\-->
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>