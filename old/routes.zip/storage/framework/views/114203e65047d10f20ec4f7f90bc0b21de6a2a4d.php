<div class="widget widget-sidebar recent-properties">
    <h4><span><?php echo e(__('general.quick-links')); ?></span> <img src="<?php echo e(asset('public/frontend/images/divider-half.png')); ?>" alt=""></h4>
    <div class="widget-content box">
        <ul class="bullet-list">
            <!-- <li><a href="#">Featured Properties</a></li> -->
            <li><a href="<?php echo e(route('search-property', $locale)); ?>?limit=9&action=1"><?php echo e(__('general.properties-for-sale')); ?></a></li>
            <li><a href="<?php echo e(route('search-property', $locale)); ?>?limit=9&action=2"><?php echo e(__('general.properties-for-rent')); ?></a></li>
            <li><a href="<?php echo e(route('service', $locale)); ?>"><?php echo e(__('general.our-service')); ?></a></li>
            <li><a href="<?php echo e(route('team', $locale)); ?>"><?php echo e(__('general.our-team')); ?></a></li>
            <li><a href="<?php echo e(route('news', $locale)); ?>"><?php echo e(__('general.news')); ?></a></li>
            <li><a href="<?php echo e(route('about-us', $locale)); ?>"><?php echo e(__('general.about-yao')); ?></a></li>
            <li><a href="<?php echo e(route('customer', $locale)); ?>"><?php echo e(__('general.customer-require')); ?></a></li>
        </ul>
    </div>
    <!-- end widget content -->
</div>
<!-- end widget -->