<?php $__env->startSection('section-title', 'Category'); ?>
<?php $__env->startSection('tab-active-type', 'active'); ?>
<?php $__env->startSection('tab-css'); ?>
	
<?php $__env->stopSection(); ?>


<?php $__env->startSection('tab-js'); ?>
<script type="text/javascript">
	$(document).ready(function(){
		$('.item').click(function(){
			check_id = $(this).attr('for');
			category_id = $("#"+check_id).attr('category-id');
			categories(category_id);
		})
	})
	function categories(category_id){
		
		$.ajax({
		        url: "<?php echo e(route($route.'.check-categories')); ?>?restaurant_id=<?php echo e($id); ?>&category_id="+category_id,
		        type: 'GET',
		        data: { },
		        success: function( response ) {
		            if ( response.status === 'success' ) {
		            	toastr.success(response.msg);
		            }else{
		            	swal("Error!", "Sorry there is an error happens. " ,"error");
		            }
		        },
		        error: function( response ) {
		           swal("Error!", "Sorry there is an error happens. " ,"error");
		        }
		});
	}
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tab-content'); ?>

	<?php if(sizeof($categories) > 1): ?>
		<div class="row m-t-lg">
			<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php ( $check = "" ); ?>
				<?php $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($restaurant->category_id==$row->id): ?>
						<?php ( $check = "checked" ); ?>
					<?php endif; ?>
					
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<div class="col-xs-12 col-sm-6 col-sm-4 col-md-3 col-lg-3">
					<div class="checkbox-bird">
						<input type="checkbox" category-id="<?php echo e($row->id); ?>" id="category-<?php echo e($row->id); ?>" <?php echo e($check); ?> >
						<label class="item" for="category-<?php echo e($row->id); ?>"><?php echo e($row->name); ?></label>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	<?php else: ?>
	<p>No data Here</p>
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($route.'.tab', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>