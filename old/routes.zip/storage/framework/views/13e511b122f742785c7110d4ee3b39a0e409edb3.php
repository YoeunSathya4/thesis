<?php if(sizeof($data) > 0): ?>
	<div class="table-responsive">
		<table id="table-edit" class="table table-bordered table-hover">
			<thead>
				<tr>
					<th>#</th>
					<th>Listing Code</th>
					<th>Message</th>
					<th>Date</th>
					<th></th>
				</tr>
			</thead>
			<tbody>

				<?php ($i = 1); ?>
				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($i++); ?></td>
						<td>
							<?php ($property = $row->property); ?>
							<?php echo e(makeListingCode($property)); ?>

						</td>
						<td>
							<textarea id="message-<?php echo e($row->id); ?>" name="message" class="form-control  "> <?php echo e($row->message); ?> </textarea>
						</td>
						<td><?php echo e($row->created_at); ?></td>
						<td style="white-space: nowrap; width: 1%;">
							<div class="tabledit-toolbar btn-toolbar" style="text-align: left;">
	                           	<div class="btn-group btn-group-sm" style="float: none;">
	                           		<?php if(checkPermision($route.'.update-inquiry')): ?><button onclick="update(<?php echo e($row->id); ?>)" class="tabledit-edit-button btn btn-sm btn-success" style="float: none;"><span class="fa fa-save"></span></button><?php endif; ?>
	                           		<?php if(checkPermision($route.'.trash-inquiry')): ?><button onclick="deleteConfirm('<?php echo e(route($route.'.trash-inquiries', $row->id)); ?>', '<?php echo e(route($route.'.inquiries',$id)); ?>')" class="tabledit-edit-button btn btn-sm btn-danger" style="float: none;"><span class="fa fa-trash"></span></button><?php endif; ?>
	                           	</div>
	                       </div>
	                    </td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div >
	<?php else: ?>
		<span>No Data</span>
	<?php endif; ?>