<?php if(count($data)>0): ?>
<table id="pop-table" class="table pop">
	<thead>
		<th>Name</th>
		<th>Position</th>
		<th>Role</th>
		<th></th>
	</thead>
	<tbody>
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($row->name); ?></td>
				<td><?php echo e($row->position); ?> </td>
				<td>
					<select id="role-<?php echo e($row->id); ?>">
					<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($role->id); ?>" ><?php echo e($role->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</td>
				<td width=8%><i onclick="add(<?php echo e($row->id); ?>)" class="fa fa-plus"></i></td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<?php else: ?>
	No Data Avaiable
<?php endif; ?>
