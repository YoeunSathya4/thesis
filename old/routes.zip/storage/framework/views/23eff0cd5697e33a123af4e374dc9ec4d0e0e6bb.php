<?php $__env->startSection('section-title', 'Featured Properties'); ?>
<?php $__env->startSection('section-css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('section-js'); ?>
<script type="text/javascript">	
	var source;
	function isbefore(a, b) {
	    if (a.parentNode == b.parentNode) {
	        for (var cur = a; cur; cur = cur.previousSibling) {
	            if (cur === b) {
	                return true;
	            }
	        }
	    }
	    return false;
	}

	function dragenter(e) {
		
	    var targetelem = e.target;
	    //console.log(e);
	    if (targetelem.nodeName == "TD") {
	       targetelem = targetelem.parentNode;   
	    }  
	    
	    if (isbefore(source, targetelem)) {
	        targetelem.parentNode.insertBefore(source, targetelem);
	        //console.log('moved :'+order);
	    } else {
	        targetelem.parentNode.insertBefore(source, targetelem.nextSibling);

	    }
	}

	function dragstart(e) {
	    source = e.target;
	    e.dataTransfer.effectAllowed = 'move';

	}
	function dragend(e){
		//console.log(e.target);
		elements = $(".moveable");
		//console.log(elements);
		data = [];
		for(i=0; i<elements.length; i++){
			var obj = new Object();
			obj.id = $('#'+elements[i].id).attr('data-id');
			obj.order = i+1;
			data[i] = obj;
		}
		
		var string = JSON.stringify(data);
		console.log(string);
		$.ajax({
		        url: "<?php echo e(route('user.property.property.re-order-feature')); ?>",
		        type: 'POST',
		        data: {string:string},
		        success: function( response ) {
		         	console.log(response);
				    
		        },
		        error: function( response ) {
		           swal("Error!", "Sorry there is an error happens. " ,"error");
		        }
					
		});
	}
	function updateStatus(id){
     	
     	$.ajax({
	        url: "<?php echo e(route($route.'.property.remove-feature')); ?>",
	        method: 'POST',
	        data: {id:id },
	        success: function( response ) {
	            if ( response.status === 'success' ) {
	            	
	            	window.location.replace("<?php echo e(route($route.'.property.feature')); ?>");
	            	
	            }else{
	            	swal("Error!", "Sorry there is an error happens. " ,"error");
	            }
	        },
	        error: function( response ) {
	           swal("Error!", "Sorry there is an error happens. " ,"error");
	        }
		});
	}

</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section-content'); ?>
	
	<?php if(sizeof($data) > 0): ?>
	<div class="table-responsive">
		<table id="table-edit" class="table table-bordered table-hover">
			<thead>
				<tr>
					<th>#</th>
					<th>Code</th>
					<th>Action</th>
					<th>Type</th>
					<th>Title</th>
					<th>Status</th>
					<th></th>
				</tr>
			</thead>
			<tbody ondrop="alert('ddd')">

				<?php ($i = 1); ?>
				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr id="element-<?php echo e($row->id); ?>" data-id="<?php echo e($row->id); ?>" class="moveable" feature-order="<?php echo e($row->featured_order); ?>" draggable="true" ondragenter="dragenter(event)" ondragstart="dragstart(event)" ondragend="dragend(event)">
						<td><?php echo e($i++); ?></td>
						<td><?php echo e($row->listing_code); ?></td>
						<td><?php echo e($row->action->en_name); ?></td>
						<td><?php echo e($row->type->en_name); ?></td>
						<td><?php echo e($row->en_name); ?></td>
						<td>
							<div class="checkbox-toggle">
						        <input onclick="updateStatus(<?php echo e($row->id); ?>)" type="checkbox" id="status-<?php echo e($row->id); ?>" <?php if($row->is_featured == 1): ?> checked data-value="1" <?php else: ?> data-value="0" <?php endif; ?> >
						        <label for="status-<?php echo e($row->id); ?>"></label>
					        </div>
						</td>
						<td style="white-space: nowrap; width: 1%;">
							<div class="tabledit-toolbar btn-toolbar" style="text-align: left;">
	                           	<div class="btn-group btn-group-sm" style="float: none;">
	                           		<a href="<?php echo e(route($route.'.edit', $row->id)); ?>" class="tabledit-edit-button btn btn-sm btn-success" style="float: none;"><span class="fa fa-eye"></span></a>
	                           	</div>
	                       </div>
	                    </td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div >
	<?php else: ?>
	<span>No Data</span>
	<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make($route.'.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>