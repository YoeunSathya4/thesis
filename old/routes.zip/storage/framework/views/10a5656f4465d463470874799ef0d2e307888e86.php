<?php $__env->startSection('title', 'New Password'); ?>
<?php $__env->startSection('bottom-js'); ?>
	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('auth'); ?>
 		<div class="admin-sidebar-secondary">
            <div class="admin-sidebar-secondary-inner">
                <div class="admin-sidebar-secondary-inner-top">
                    <h1>New Password</h1>
                    
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>


                    <form method="post" action="<?php echo e(route('customer.reset', $locale)); ?>">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <input type="hidden" name="token" value="<?php echo e($token); ?>">


                        <div class="form-group">
                            <input type="email" name="email" class="form-control" placeholder="E-mail" required value="<?php echo e(isset($email) ? $email : old('email')); ?>">
                        </div>
                        <div class="form-group">
                            <input type="password" name="password" class="form-control" placeholder="Password" required value="1234567">
                        </div>
                        <div class="form-group">
                            <input type="password" name="password_confirmation" class="form-control" placeholder="Confirmed Password" required value="1234567">
                        </div>
                        <!-- /.form-group -->

                        <button type="submit" class="btn btn-xl pull-right"> <i class="fa fa-user-plus"></i> Reset</button>
                    </form>
                </div>
                <!-- /.admin-sidebar-secondary-inner-top -->

                <div class="admin-sidebar-secondary-inner-bottom">
                    <?php echo $__env->make('customer.auth.footer', ['locale'=>$locale, 'page'=>'register'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <!-- /.admin-landing-content-footer -->
                </div>
                <!-- /.admin-sidebar-secondary-inner-bottom -->
            </div>
            <!-- /.admin-sidebar-secondary-inner -->
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('landing'); ?>
<div class="admin-landing-image-source"></div>
<div class="admin-landing-image-cover"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>