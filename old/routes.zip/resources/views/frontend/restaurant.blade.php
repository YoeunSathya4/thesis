@extends('frontend/layouts.master')

@section('title', 'Restaurant')
@section('service', 'active')

@section ('appbottomjs')     
@endsection
@section ('content')

@endsection